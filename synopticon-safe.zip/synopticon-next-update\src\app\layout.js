import "./globals.css";
import NavBar from '../components/NavBar';
import Footer from '../components/Footer';

export const metadata = {
  title: "警察署評価マップ | 全国の警察の対応を監査・可視化",
  description: "警察署評価マップは市民の証言に基づき、全国の警察署の受理率・対応の公正さ・不作為を透明化する国民監査プラットフォームです。",
};

export default function RootLayout({ children }) {
  return (
    <html lang="ja">
      <body className="antialiased overflow-x-hidden selection:bg-indigo-500/30">
        <div className="fixed inset-0 bg-[radial-gradient(circle_at_50%_-20%,#1E293B,transparent)] pointer-events-none"></div>
        <div className="relative z-10 min-h-screen">
          <NavBar />
          <main>{children}</main>
          <Footer />
        </div>
      </body>
    </html>
  );
}
