"use client";

import { useState, useEffect } from 'react';
import { useParams, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import { 
  AlertOctagon,
  Clock,
  Lock,
  Unlock,
  CheckCircle,
  ThumbsUp,
  ThumbsDown,
  ArrowRight,
  ShieldCheck,
  ChevronRight,
  Scale,
  Search
} from 'lucide-react';
import { supabase } from '../../../lib/supabaseClient';

export default function CaseResolutionPage() {
  const params = useParams();
  const searchParams = useSearchParams();
  const caseId = params.id;
  
  const [formData, setFormData] = useState({
    resolved: null,
    resolutionDetails: '',
    finalEvalAttitude: 0,
    finalEvalFairness: 0,
    finalEvalSpeed: 0,
  });

  const [hasAgreed, setHasAgreed] = useState(false);
  const [isSubmitted, setIsSubmitted] = useState(false);
  const [targetReport, setTargetReport] = useState(null);
  
  // Anti-tampering states
  const [isLocked, setIsLocked] = useState(true);
  const [timeRemaining, setTimeRemaining] = useState({ hours: 48, mins: 0 });
  const [debugMode, setDebugMode] = useState(false);
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    
    if (searchParams.get('debug') === 'true') {
      setIsLocked(false);
    }
    
    let reportTime = null;

    const checkCoolOffPeriod = () => {
      if (!reportTime && !debugMode) return;
      const elapsed = Date.now() - (reportTime || 0);
      const coolOffPeriod = 48 * 60 * 60 * 1000; // 48 hours
      
      if (elapsed >= coolOffPeriod || debugMode) {
        setIsLocked(false);
      } else {
        setIsLocked(true);
        const remaining = coolOffPeriod - elapsed;
        setTimeRemaining({
          hours: Math.floor(remaining / (1000 * 60 * 60)),
          mins: Math.floor((remaining % (1000 * 60 * 60)) / (1000 * 60))
        });
      }
    };

    const fetchReport = async () => {
      try {
        const { data, error } = await supabase
          .from('reports')
          .select('*')
          .eq('case_number', caseId)
          .single();
          
        if (error) throw error;
        
        if (data) {
          const mappedReport = {
            caseNumber: data.case_number,
            submittedAt: new Date(data.submitted_at).getTime()
          };
          setTargetReport(mappedReport);
          reportTime = mappedReport.submittedAt;
          checkCoolOffPeriod();
        }
      } catch(e) {
        console.error("Failed to fetch report from Supabase", e);
      }
    };

    fetchReport();
    const interval = setInterval(checkCoolOffPeriod, 60000); // Check every minute
    
    return () => clearInterval(interval);
  }, [caseId, searchParams, debugMode]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (isLocked) return;

    const resolutionScore = (formData.evalInvestigation + formData.evalFairness) / 2;

    try {
      const { error } = await supabase
        .from('reports')
        .update({ 
          problem_resolved: true,
          resolution_score: resolutionScore
        })
        .eq('case_number', caseId);

      if (error) throw error;
      
      setIsSubmitted(true);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch(err) {
      console.error("Failed to update report", err);
      alert("通信エラーが発生しました。");
    }
  };

  const handleRating = (key, val) => {
    setFormData(prev => ({ ...prev, [key]: val }));
  };

  if (!isMounted) return null;

  if (isSubmitted) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 pt-24 pb-32">
        <div className="max-w-2xl w-full glass-card p-12 text-center animate-in zoom-in duration-500">
          <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-8">
            <ShieldCheck className="w-12 h-12 text-emerald-600" />
          </div>
          <h2 className="text-3xl font-black text-slate-900 mb-4 tracking-tighter uppercase">解決レポートを受理しました</h2>
          <p className="text-slate-500 font-medium mb-8 leading-relaxed">
            ご報告ありがとうございます。追加データは「解決スコア」として警察署の総合評価に反映されます。<br/>
            警察署の初期対応と最終的な解決のギャップは、監査データとして全国の統計ページで公開されます。
          </p>
          <Link href="/stats" className="inline-flex items-center space-x-2 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-900 px-8 py-4 rounded-2xl font-black transition-all uppercase tracking-widest text-sm shadow-sm">
            全国統計を見る
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-32">
      <div className="max-w-3xl mx-auto px-6">
        
        {/* Header */}
        <div className="text-center mb-12 relative">
          <div className="absolute right-0 top-0">
            {/* デバッグ用ボタン: 本番環境では削除してください */}
            <button 
              onClick={() => setDebugMode(!debugMode)}
              className="text-[8px] bg-slate-100 border border-slate-200 text-slate-400 px-2 py-1 rounded"
            >
              [Debug] Skip Cool-off
            </button>
          </div>
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-indigo-100 mb-6">
            <Scale className="w-8 h-8 text-indigo-600" />
          </div>
          <h1 className="text-4xl font-black text-slate-900 mb-4 tracking-tighter uppercase">Case Resolution Report</h1>
          <p className="text-slate-500 font-bold text-sm max-w-xl mx-auto">
            追跡中のインシデントに関する進展や解決状況を報告し、当該警察署の「解決スコア」を更新します。
          </p>
          <div className="mt-6 inline-flex items-center space-x-2 bg-slate-100 border border-slate-200 px-4 py-2 rounded-lg">
            <Search className="w-4 h-4 text-indigo-600" />
            <span className="text-xs font-black text-slate-500 uppercase tracking-widest">Tracking ID:</span>
            <span className="text-sm font-mono font-black text-indigo-600">{caseId}</span>
          </div>
        </div>

        {/* Info & Scoring Mechanism Explanation */}
        <div className="mb-8 glass-card p-6 border-indigo-200 bg-indigo-50">
          <h3 className="text-xs font-black text-indigo-600 uppercase tracking-widest mb-3 flex items-center">
            <AlertOctagon className="w-4 h-4 mr-2" />
            二段階評価システムについて
          </h3>
          <p className="text-xs text-slate-600 font-bold leading-relaxed">
            警察マップの監査評価は「初動スコア（報告時）」と「解決スコア（本フォーム）」の加重平均で算出されます。
            初期対応が悪かった場合でも、その後の捜査や対応によって事態が改善・解決された場合は、解決スコアが高く評価され、警察署の総合信頼性が上昇します。
          </p>
        </div>

        {/* Anti-tampering Lock Screen */}
        {isLocked ? (
          <div className="glass-card p-12 text-center animate-in fade-in duration-500 border border-amber-200 bg-amber-50">
            <div className="w-20 h-20 bg-amber-100 rounded-full flex items-center justify-center mx-auto mb-6 relative">
              <Lock className="w-10 h-10 text-amber-600" />
              <div className="absolute -bottom-2 -right-2 bg-white rounded-full p-1 border border-slate-200 shadow-sm">
                <Clock className="w-4 h-4 text-amber-600" />
              </div>
            </div>
            <h2 className="text-2xl font-black text-slate-900 mb-4 tracking-tighter">冷却期間（Anti-Tampering）</h2>
            <div className="text-4xl font-mono font-black text-amber-600 mb-6 tracking-widest">
              {timeRemaining.hours.toString().padStart(2, '0')}:{timeRemaining.mins.toString().padStart(2, '0')}
              <span className="text-sm ml-2 text-amber-600/70">REMAINING</span>
            </div>
            <div className="max-w-md mx-auto text-left space-y-4">
              <p className="text-sm text-slate-600 font-bold leading-relaxed">
                報復的な低評価や感情的な改竄を防ぐため、初回レポート提出から<strong className="text-slate-900">48時間</strong>は解決レポートを送信できません。
              </p>
              <ul className="text-xs text-slate-500 space-y-2 list-disc pl-4 font-medium">
                <li>警察組織が捜査や対応を検討・実行するための合理的な猶予期間です。</li>
                <li>このロックはブラウザに記録されたタイムスタンプに基づいて解除されます。</li>
              </ul>
            </div>
          </div>
        ) : (
          /* Resolution Form */
          <form onSubmit={handleSubmit} className="glass-card p-8 md:p-12 relative overflow-hidden animate-in fade-in slide-in-from-bottom-8 duration-500">
            <div className="absolute top-0 right-0 p-6 opacity-20">
              <Unlock className="w-16 h-16 text-indigo-500" />
            </div>

            <div className="space-y-10 relative z-10">
              {/* Status Update */}
              <div className="space-y-4">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center">
                  <span className="bg-indigo-600 text-white w-4 h-4 flex items-center justify-center rounded-full mr-2">1</span>
                  現在の進展・解決ステータス
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => setFormData({...formData, resolved: true})}
                    className={`flex items-center justify-center space-x-3 p-6 rounded-2xl border-2 transition-all ${formData.resolved === true ? 'bg-emerald-50 border-emerald-500 text-emerald-600 shadow-sm' : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100'}`}
                  >
                    <ThumbsUp className="w-6 h-6" />
                    <span className="font-black text-sm">事態が進展・解決した</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({...formData, resolved: false})}
                    className={`flex items-center justify-center space-x-3 p-6 rounded-2xl border-2 transition-all ${formData.resolved === false ? 'bg-rose-50 border-rose-500 text-rose-600 shadow-sm' : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100'}`}
                  >
                    <ThumbsDown className="w-6 h-6" />
                    <span className="font-black text-sm">依然として放置・未解決</span>
                  </button>
                </div>
              </div>

              {/* Final Evaluation */}
              <div className="space-y-6">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center">
                  <span className="bg-indigo-600 text-white w-4 h-4 flex items-center justify-center rounded-full mr-2">2</span>
                  最終的な警察対応の評価（解決スコア）
                </label>
                
                {[
                  { key: 'finalEvalAttitude', label: '最終的な態度・誠実さ', desc: 'その後の対応で態度は改善されたか' },
                  { key: 'finalEvalFairness', label: '捜査の実効性', desc: '実際に動いてくれたか、証拠を検証したか' },
                  { key: 'finalEvalSpeed', label: '解決までのスピード', desc: '不当な遅延なく事態が収拾したか' }
                ].map((metric) => (
                  <div key={metric.key} className="bg-slate-50 border border-slate-200 p-6 rounded-2xl">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between mb-4 gap-4">
                      <div>
                        <h3 className="text-sm font-black text-slate-900">{metric.label}</h3>
                        <p className="text-[10px] font-bold text-slate-500 mt-1">{metric.desc}</p>
                      </div>
                      <div className="flex space-x-2">
                        {[1, 2, 3, 4, 5].map((val) => (
                          <button
                            key={val}
                            type="button"
                            onClick={() => handleRating(metric.key, val)}
                            className={`w-10 h-10 rounded-xl flex items-center justify-center font-black transition-all ${formData[metric.key] === val ? (val <= 2 ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30' : val >= 4 ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30' : 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/30') : 'bg-white border border-slate-200 text-slate-400 hover:bg-slate-100'}`}
                          >
                            {val}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              {/* Details */}
              <div className="space-y-3">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center">
                  <span className="bg-indigo-600 text-white w-4 h-4 flex items-center justify-center rounded-full mr-2">3</span>
                  進展の詳細・追加コメント
                </label>
                <textarea 
                  required
                  rows="5"
                  placeholder="例：後日別の担当者から連絡があり、防犯カメラの映像を確認してくれた。被害届も無事受理された。"
                  value={formData.resolutionDetails}
                  onChange={e => setFormData({...formData, resolutionDetails: e.target.value})}
                  className="w-full bg-slate-50 border-slate-200 rounded-xl p-4 text-sm font-bold text-slate-900 focus:ring-indigo-500 focus:bg-white transition-all outline-none border resize-none"
                />
              </div>

              {/* Legal Agreement */}
              <div className="pt-6 border-t border-slate-200">
                <label className="flex items-start space-x-3 cursor-pointer group p-4 bg-rose-50 border border-rose-200 rounded-xl">
                  <div className="relative flex items-center justify-center mt-0.5">
                    <input 
                      type="checkbox" 
                      checked={hasAgreed}
                      onChange={(e) => setHasAgreed(e.target.checked)}
                      className="peer appearance-none w-5 h-5 border-2 border-rose-300 rounded bg-white checked:bg-rose-600 checked:border-rose-600 transition-all cursor-pointer"
                    />
                    <CheckCircle className="w-3 h-3 text-white absolute opacity-0 peer-checked:opacity-100 pointer-events-none transition-opacity" />
                  </div>
                  <div>
                    <div className="text-[11px] font-black text-rose-600 uppercase tracking-widest mb-1">法的誓約（データ更新の承認）</div>
                    <div className="text-[10px] text-slate-600 font-bold leading-relaxed">
                      私は、この追記内容が事実に基づく進展であることを誓約します。<br/>
                      虚偽の報告によって警察署の評価を不当に操作（改竄）した場合、ペナルティとして報告が無効化されることに同意します。
                    </div>
                  </div>
                </label>
              </div>

              {/* Submit */}
              <div className="flex justify-end">
                <button 
                  type="submit"
                  disabled={formData.resolved === null || formData.finalEvalSpeed === 0 || !formData.resolutionDetails || !hasAgreed}
                  className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white px-10 py-5 rounded-2xl font-black transition-all shadow-xl uppercase tracking-widest text-sm disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  <span>解決スコアを確定し送信</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          </form>
        )}

      </div>
    </div>
  );
}
