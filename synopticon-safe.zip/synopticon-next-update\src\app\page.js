"use client";

import Link from 'next/link';
import { 
  ShieldAlert, 
  BarChart3, 
  ChevronRight, 
  Scale, 
  Eye, 
  ThumbsUp, 
  ArrowRight,
  ShieldCheck,
  Search,
  BellRing,
  Flame,
  TrendingUp,
  MapPin
} from 'lucide-react';

export default function Home() {
  return (
    <div className="min-h-screen pt-20 pb-32">
      
      {/* ヒーローセクション */}
      <div className="relative pt-24 pb-32 px-6 overflow-hidden">
        {/* 背景の装飾 */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[800px] h-[800px] bg-indigo-500/10 blur-[120px] rounded-full pointer-events-none -z-10" />
        <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-emerald-500/5 blur-[100px] rounded-full pointer-events-none -z-10" />

        <div className="max-w-5xl mx-auto text-center animate-in fade-in slide-in-from-bottom-8 duration-1000">


          <h1 className="font-black text-slate-900 tracking-tighter leading-[1.3] sm:leading-[1.2] mb-8 flex flex-col gap-2 sm:gap-4">
            <span className="text-xl sm:text-2xl md:text-4xl text-slate-700">『助けを求める声』をデータに変え、</span>
            <span className="text-3xl sm:text-5xl md:text-6xl">
              警察の対応を<span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600">可視化</span>する。
            </span>
          </h1>
          
          <p className="text-lg text-slate-600 font-bold mb-12 max-w-2xl mx-auto leading-relaxed">
            『警察署評価マップ』は、市民の証言に基づき、全国の警察署の受理率と対応の公正さを可視化する中立的な監査プラットフォームです。<br className="hidden md:block" />
            不当な「あしらい」は客観的データとして記録し、真摯な対応は称賛することで、公的機関の本来あるべき姿を取り戻します。
          </p>

          <div className="flex flex-col sm:flex-row flex-wrap items-center justify-center gap-4">
            <Link 
              href="/report"
              className="w-full sm:w-auto inline-flex items-center justify-center space-x-3 bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-5 rounded-2xl font-black transition-all uppercase tracking-widest text-sm shadow-xl shadow-indigo-600/20 hover:-translate-y-1"
            >
              <ShieldAlert className="w-5 h-5" />
              <span>監査レポートを作成</span>
              <ChevronRight className="w-4 h-4" />
            </Link>

            <Link 
              href="/news"
              className="w-full sm:w-auto inline-flex items-center justify-center space-x-3 bg-amber-50 hover:bg-amber-100 border border-amber-200 text-amber-700 px-8 py-5 rounded-2xl font-black transition-all uppercase tracking-widest text-sm shadow-sm hover:-translate-y-1"
            >
              <BellRing className="w-5 h-5 text-amber-600" />
              <span>ニュースを見る</span>
            </Link>
            
            <Link 
              href="/stats"
              className="w-full sm:w-auto inline-flex items-center justify-center space-x-3 bg-white hover:bg-slate-50 border border-slate-200 text-slate-900 px-8 py-5 rounded-2xl font-black transition-all uppercase tracking-widest text-sm shadow-sm hover:-translate-y-1"
            >
              <BarChart3 className="w-5 h-5 text-indigo-600" />
              <span>全国の統計データ</span>
            </Link>
          </div>
        </div>
      </div>

      {/* 警戒ホットスポット */}
      <div className="max-w-4xl mx-auto px-6 pb-20">
        <div className="bg-white border border-slate-200 rounded-3xl p-6 sm:p-8 shadow-sm relative overflow-hidden">
          <div className="absolute top-0 right-0 w-32 h-32 bg-rose-500/10 blur-[50px] rounded-full pointer-events-none" />
          
          <div className="flex items-center space-x-3 mb-6">
            <div className="bg-rose-100 p-2 rounded-xl">
              <Flame className="w-5 h-5 text-rose-600" />
            </div>
            <h3 className="text-xl font-black text-slate-900 tracking-tighter">全国の警戒ホットスポット（急増エリア）</h3>
          </div>

          <div className="space-y-3">
            {[
              { rank: 1, region: '東京都 渋谷区・新宿区', desc: '自転車盗難・ひったくりが前月比150%増', color: 'rose' },
              { rank: 2, region: '埼玉県 南部エリア', desc: 'CANインベーダー等による車両盗難が急増', color: 'rose' },
              { rank: 3, region: '大阪府 北部エリア', desc: '点検強盗の予兆となる不審な訪問が多発', color: 'amber' },
              { rank: 4, region: '愛知県 名古屋市', desc: '深夜の車上荒らし・部品狙いが連続発生', color: 'amber' },
              { rank: 5, region: '福岡県 福岡市周辺', desc: '帰宅途中の女性を狙ったつきまとい事案が散発', color: 'amber' },
            ].map((spot) => (
              <div key={spot.rank} className={`flex flex-col sm:flex-row sm:items-center p-4 rounded-2xl border transition-colors ${
                spot.color === 'rose' 
                  ? 'bg-rose-50/50 border-rose-100 hover:bg-rose-50' 
                  : 'bg-amber-50/30 border-amber-100 hover:bg-amber-50'
              }`}>
                <div className="flex items-center space-x-4 mb-2 sm:mb-0 sm:w-[40%] shrink-0">
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center font-black text-sm shrink-0 ${
                    spot.color === 'rose' ? 'bg-rose-600 text-white' : 'bg-amber-500 text-white'
                  }`}>
                    {spot.rank}
                  </div>
                  <div className="flex items-center space-x-1">
                    <MapPin className={`w-4 h-4 ${spot.color === 'rose' ? 'text-rose-500' : 'text-amber-500'}`} />
                    <span className="font-black text-slate-900 text-sm">{spot.region}</span>
                  </div>
                </div>
                
                <div className="flex items-center sm:pl-4 sm:border-l border-slate-200/60">
                  <TrendingUp className={`w-4 h-4 mr-2 shrink-0 ${spot.color === 'rose' ? 'text-rose-400' : 'text-amber-400'}`} />
                  <span className="text-sm font-bold text-slate-600">{spot.desc}</span>
                </div>
              </div>
            ))}
          </div>
          
          <div className="mt-6 text-center">
            <Link href="/news" className="inline-flex items-center text-xs font-black text-slate-500 hover:text-indigo-600 transition-colors uppercase tracking-widest">
              <span>すべての要注意事象を見る</span>
              <ChevronRight className="w-3 h-3 ml-1" />
            </Link>
          </div>
        </div>
      </div>

      {/* ミッション・3つの柱 */}
      <div className="max-w-6xl mx-auto px-6 py-20 border-t border-slate-100">
        <div className="text-center mb-16">
          <h2 className="text-sm font-black text-indigo-600 uppercase tracking-widest mb-3">Core Principles</h2>
          <h3 className="text-3xl font-black text-slate-900 tracking-tighter">データがもたらす「公正な抑止力」</h3>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          
          {/* Transparency */}
          <div className="glass-card p-8 group hover:-translate-y-2 transition-all duration-300">
            <div className="w-14 h-14 bg-indigo-50 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <Eye className="w-7 h-7 text-indigo-600" />
            </div>
            <h4 className="text-xl font-black text-slate-900 mb-4 tracking-tighter">透明化・可視化</h4>
            <p className="text-sm text-slate-500 font-bold leading-relaxed">
              「民事不介入」「証拠不十分」といった理由での不当な門前払い（不受理）をデータとして蓄積。密室で行われる対応の「実効受理率」を全国規模で可視化します。
            </p>
          </div>

          {/* Fairness */}
          <div className="glass-card p-8 group hover:-translate-y-2 transition-all duration-300">
            <div className="w-14 h-14 bg-emerald-50 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <Scale className="w-7 h-7 text-emerald-600" />
            </div>
            <h4 className="text-xl font-black text-slate-900 mb-4 tracking-tighter">公平な評価</h4>
            <p className="text-sm text-slate-500 font-bold leading-relaxed">
              当プラットフォームは警察への一方的な非難を目的としません。親身な対応や、市民に寄り添った行動は「優良対応」として加点され、感謝の声とともに称賛されます。
            </p>
          </div>

          {/* Tracking */}
          <div className="glass-card p-8 group hover:-translate-y-2 transition-all duration-300">
            <div className="w-14 h-14 bg-rose-50 rounded-2xl flex items-center justify-center mb-6 group-hover:scale-110 transition-transform">
              <Search className="w-7 h-7 text-rose-600" />
            </div>
            <h4 className="text-xl font-black text-slate-900 mb-4 tracking-tighter">解決トラッキング</h4>
            <p className="text-sm text-slate-500 font-bold leading-relaxed">
              一度不受理にされた事案には固有の追跡IDを発行。「初期対応は悪かったが、後に動いてくれたか」という二段階の経過を追跡し、組織としての誠実さを測ります。
            </p>
          </div>

        </div>
      </div>

      {/* How it works */}
      <div className="max-w-5xl mx-auto px-6 py-20">
        <div className="glass-card p-10 md:p-16 border-indigo-100 bg-gradient-to-br from-indigo-50/50 to-white">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <h3 className="text-2xl font-black text-slate-900 tracking-tighter leading-tight">
                「助けて」の声を<br/>社会全体の記録に変える。
              </h3>
              <p className="text-sm text-slate-600 font-bold leading-relaxed">
                法律上、警察には被害届を原則として受理する義務（犯罪捜査規範 第61条）があります。しかし現場の都合でそれが守られないケースが多発しています。
              </p>
              <p className="text-sm text-slate-600 font-bold leading-relaxed">
                あなたの経験をレポートとして提出することで、特定の警察署の傾向が可視化され、組織内部への強力な監査プレッシャー（抑止力）として機能します。
              </p>
              <ul className="space-y-3 pt-4">
                <li className="flex items-center space-x-3">
                  <ShieldCheck className="w-5 h-5 text-indigo-500" />
                  <span className="text-xs font-black text-slate-700">個人を特定する情報は収集しません</span>
                </li>
                <li className="flex items-center space-x-3">
                  <ThumbsUp className="w-5 h-5 text-emerald-500" />
                  <span className="text-xs font-black text-slate-700">真面目な警察官の努力は適切に評価されます</span>
                </li>
              </ul>
            </div>
            
            <div className="relative">
              <div className="absolute inset-0 bg-indigo-500/5 blur-3xl rounded-full" />
              <div className="relative space-y-4">
                <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex items-center space-x-4 transform transition-transform hover:translate-x-2">
                  <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center font-black text-lg">1</div>
                  <div>
                    <h5 className="text-sm font-black text-slate-900">レポートの作成</h5>
                    <p className="text-[10px] font-bold text-slate-500">匿名で警察の対応内容を客観的に記録</p>
                  </div>
                </div>
                <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex items-center space-x-4 transform transition-transform hover:translate-x-2 ml-4">
                  <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center font-black text-lg">2</div>
                  <div>
                    <h5 className="text-sm font-black text-slate-900">統計データへの反映</h5>
                    <p className="text-[10px] font-bold text-slate-500">警察署別のスコアや不受理傾向として可視化</p>
                  </div>
                </div>
                <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-100 flex items-center space-x-4 transform transition-transform hover:translate-x-2 ml-8">
                  <div className="w-10 h-10 bg-indigo-100 text-indigo-600 rounded-xl flex items-center justify-center font-black text-lg">3</div>
                  <div>
                    <h5 className="text-sm font-black text-slate-900">公正な監査と抑止力</h5>
                    <p className="text-[10px] font-bold text-slate-500">データが社会的監視となり、不作為を防ぐ</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

    </div>
  );
}
