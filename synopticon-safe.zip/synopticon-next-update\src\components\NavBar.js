"use client";

import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { Shield, BarChart3, FileText, AlertOctagon, BellRing } from 'lucide-react';

/**
 * 全ページ共通のナビゲーションバー
 */
export default function NavBar() {
  const pathname = usePathname();

  const links = [
    { href: '/stats',  label: '全国統計', icon: BarChart3 },
    { href: '/report', label: 'レポート', icon: FileText },
    { href: '/news',   label: 'ニュース', icon: BellRing },
    { href: '/case',   label: '報告',     icon: AlertOctagon },
  ];

  return (
    <nav className="fixed top-0 w-full z-50 bg-white/90 backdrop-blur-md border-b border-slate-200 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 py-3 sm:py-4 flex flex-col md:flex-row md:items-center justify-between gap-4">
        
        {/* ロゴ */}
        <Link href="/stats" className="flex items-center space-x-3 group shrink-0">
          <div className="relative">
            <Shield className="w-6 h-6 sm:w-7 sm:h-7 text-indigo-500" />
            <div className="absolute inset-0 bg-indigo-500 blur-xl opacity-20 group-hover:opacity-40 transition-opacity" />
          </div>
          <div className="flex flex-col leading-none">
            <span className="text-lg sm:text-xl font-black tracking-tighter text-slate-900 whitespace-nowrap">警察署評価マップ</span>
            <span className="text-[8px] sm:text-[9px] font-black tracking-widest text-indigo-600 mt-1 whitespace-nowrap">-『助けての声』を可視化する-</span>
          </div>
        </Link>

        {/* ページ切り替えタブ */}
        <div className="flex items-center bg-slate-100 p-1 rounded-full border border-slate-200 gap-1 overflow-x-auto w-full md:w-auto [&::-webkit-scrollbar]:hidden [-ms-overflow-style:none] [scrollbar-width:none]">
          {links.map(({ href, label, icon: Icon }) => (
            <Link
              key={href}
              href={href}
              className={`flex items-center justify-center space-x-1.5 sm:space-x-2 px-4 sm:px-5 py-2 rounded-full text-[10px] sm:text-xs font-black transition-all uppercase tracking-widest shrink-0 ${
                pathname === href
                  ? 'bg-indigo-600 text-white shadow-lg'
                  : 'text-slate-500 hover:text-slate-900'
              }`}
            >
              <Icon className="w-3.5 h-3.5" />
              <span>{label}</span>
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
}
