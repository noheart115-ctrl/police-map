import { NextResponse } from 'next/server';

export async function GET() {
  const categories = [
    { id: 'non-prosecution', query: '不起訴' },
    { id: 'org-crime', query: '組織犯罪 強盗 闇バイト' },
    { id: 'fraud', query: '特殊詐欺 フィッシング詐欺' },
    { id: 'blind-spot', query: '警察 不作為 不祥事' }
  ];

  try {
    const results = [];
    
    for (const cat of categories) {
      const rssUrl = `https://news.google.com/rss/search?q=${encodeURIComponent(cat.query)}&hl=ja&gl=JP&ceid=JP:ja`;
      const response = await fetch(`https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(rssUrl)}`);
      const data = await response.json();

      if (data.status === 'ok') {
        const items = data.items.slice(0, 3).map(item => ({
          id: item.guid || Math.random().toString(36).substr(2, 9),
          category: cat.id,
          title: item.title,
          summary: item.description.replace(/<[^>]*>?/gm, '').substring(0, 150) + '...',
          date: new Date(item.pubDate).toLocaleDateString('ja-JP').replace(/\//g, '.'),
          severity: cat.id === 'non-prosecution' || cat.id === 'org-crime' ? 'critical' : 'high',
          location: '解析中',
          tags: [cat.query.split(' ')[0], 'リアルタイム']
        }));
        results.push(...items);
      }
    }

    return NextResponse.json(results);
  } catch (error) {
    console.error('News fetch error:', error);
    return NextResponse.json({ error: 'Failed to fetch news' }, { status: 500 });
  }
}
