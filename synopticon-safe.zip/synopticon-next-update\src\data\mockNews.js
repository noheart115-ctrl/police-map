export const NEWS_CATEGORIES = [
  { id: 'all', label: 'すべて' },
  { id: 'org-crime', label: '組織犯罪' },
  { id: 'blind-spot', label: '社会の死角' },
  { id: 'non-prosecution', label: '不起訴処分' },
  { id: 'fraud', label: '詐欺アラート' }
];

export const MOCK_NEWS = [
  {
    id: 1,
    category: 'org-crime',
    title: '「トクリュウ（匿名・流動型犯罪グループ）」による広域強盗が深刻化',
    summary: 'SNSで実行役を募る「闇バイト」を駆使した新たな犯罪形態。指示役が匿名化されているため、末端が検挙されても組織の壊滅に至らないケースが多発している。',
    date: '2026.05.07',
    severity: 'critical',
    location: '全国 / 関東圏',
    tags: ['トクリュウ', '組織犯罪', '闇バイト']
  },
  {
    id: 2,
    category: 'blind-spot',
    title: '大阪府警、捜査員らによる容疑者への暴行で異例の大量処分',
    summary: 'スカウトグループへの家宅捜索時に不適切な有形力を行使。組織的な隠蔽や捜査情報の漏洩も疑われており、警察の自浄能力が問われている。',
    date: '2026.05.06',
    severity: 'high',
    location: '大阪府',
    tags: ['警察の不祥事', '社会の死角', '不作為']
  },
  {
    id: 3,
    category: 'fraud',
    title: '「ニセ警察官」によるキャッシュカード詐取が急増',
    summary: '警察官を騙り「口座が犯罪に利用されている」と不安を煽る手口。若い世代も実行役として加担しており、社会的な包囲網の構築が急務。',
    date: '2026.05.07',
    severity: 'high',
    location: '全国',
    tags: ['特殊詐欺', 'ニセ警察官', '防犯']
  },
  {
    id: 4,
    category: 'non-prosecution',
    title: '【監視対象】特殊詐欺グループ幹部、証拠不十分で不起訴処分',
    summary: '実行役の供述のみでは共謀の立証が困難と判断。指示役が法的追及を逃れる「法の死角」が顕在化しており、司法制度の限界が指摘されている。',
    date: '2026.05.05',
    severity: 'critical',
    location: '東京都',
    tags: ['不起訴', '司法の限界', '組織犯罪']
  },
  {
    id: 5,
    category: 'blind-spot',
    title: '「SNS投資詐欺」の背後に潜む、海外拠点の犯罪シンジケート',
    summary: '東南アジアを拠点とした大規模な詐欺グループの存在。日本警察の捜査権が及ばない「国外の死角」を利用しており、国際捜査協力の遅れが被害を拡大させている。',
    date: '2026.05.04',
    severity: 'mid',
    location: 'タイ / ラオス',
    tags: ['社会の死角', '国際犯罪', '投資詐欺']
  },
  {
    id: 6,
    category: 'non-prosecution',
    title: '証拠品紛失により、重要参考人の送検を見送り',
    summary: '警察署内で保管されていた決定的な証拠品が「紛失」。重大な捜査ミスの結果、起訴が不可能となり、容疑者が釈放される事態となった。',
    date: '2026.05.03',
    severity: 'critical',
    location: '地方警察署',
    tags: ['不起訴', '捜査ミス', '警察の怠慢']
  }
];
