"use client";

import { useState, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import Link from 'next/link';
import { 
  ShieldAlert, 
  MapPin, 
  TrendingDown, 
  TrendingUp, 
  Scale, 
  ThumbsUp, 
  ThumbsDown,
  AlertOctagon,
  Clock,
  ArrowLeft,
  FileText,
  MessageCircle,
  Zap,
  Info
} from 'lucide-react';
import { supabase } from '../../../lib/supabaseClient';

export default function StationDetailPage() {
  const params = useParams();
  const router = useRouter();
  const stationName = decodeURIComponent(params.name);

  const [reports, setReports] = useState([]);
  const [stationStats, setStationStats] = useState({
    totalReports: 0,
    resolvedCases: 0,
    acceptanceRate: 0,
    averageScore: 0,
    cautionCrimes: [],
    gratitudeComments: []
  });
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    
    const fetchStationReports = async () => {
      try {
        const { data: reports, error } = await supabase
          .from('reports')
          .select('*')
          .eq('police_station', stationName);
          
        if (error) throw error;
        
        if (reports) {
          // Map DB snake_case to frontend camelCase
          const targetReports = reports.map(r => ({
            caseNumber: r.case_number,
            incidentYearMonth: r.incident_year_month,
            region: r.region,
            prefecture: r.prefecture,
            policeStation: r.police_station,
            problemResolved: r.problem_resolved,
            evidenceLevel: r.evidence_level,
            incidentTypes: r.incident_types,
            otherIncidentType: r.other_incident_type,
            denialReasons: r.denial_reasons,
            evalListening: r.eval_listening,
            evalLegalExplanation: r.eval_legal_explanation,
            evalAttitude: r.eval_attitude,
            evalInvestigation: r.eval_investigation,
            evalFairness: r.eval_fairness,
            hasSupportProposal: r.has_support_proposal,
            isCivilInterventionRefused: r.is_civil_intervention_refused,
            isExcellentResponse: r.is_excellent_response,
            gratitudeComment: r.gratitude_comment,
            submittedAt: new Date(r.submitted_at).getTime()
          }));
          
          // 日付の新しい順にソート（submittedAt がない場合は末尾に）
          targetReports.sort((a, b) => (b.submittedAt || 0) - (a.submittedAt || 0));
          
          setReports(targetReports);

        // 統計データを計算
        let totalResolved = 0;
        let totalScoreSum = 0;
        let validScoreCount = 0;
        const crimesAgg = {};
        const gratitudeList = [];

        targetReports.forEach(report => {
          if (report.problemResolved === true) {
            totalResolved += 1;
          } else {
            // 不受理カテゴリの集計
            if (report.incidentTypes && Array.isArray(report.incidentTypes)) {
              report.incidentTypes.forEach(type => {
                const crimeName = type === 'その他' && report.otherIncidentType ? report.otherIncidentType.trim() : type;
                if (!crimeName) return;
                crimesAgg[crimeName] = (crimesAgg[crimeName] || 0) + 1;
              });
            } else if (report.incidentType) {
              const crimeName = report.incidentType === 'その他' && report.otherIncidentType ? report.otherIncidentType.trim() : report.incidentType;
              if (crimeName) {
                 crimesAgg[crimeName] = (crimesAgg[crimeName] || 0) + 1;
              }
            }
          }

          // スコアの集計
          const reportScore = (report.evalListening + report.evalLegalExplanation + report.evalAttitude + report.evalInvestigation + report.evalFairness) / 5;
          if (!isNaN(reportScore) && reportScore > 0) {
            totalScoreSum += reportScore;
            validScoreCount += 1;
          }

          // 感謝の声
          if (report.gratitudeComment && report.gratitudeComment.trim() !== '') {
            gratitudeList.push(report.gratitudeComment.trim());
          }
        });

        setStationStats({
          totalReports: targetReports.length,
          resolvedCases: totalResolved,
          acceptanceRate: targetReports.length > 0 ? Math.round((totalResolved / targetReports.length) * 100) : 0,
          averageScore: validScoreCount > 0 ? (totalScoreSum / validScoreCount).toFixed(1) : 0,
          cautionCrimes: Object.entries(crimesAgg).map(([name, count]) => ({ name, count })).sort((a, b) => b.count - a.count),
          gratitudeComments: gratitudeList
        });

        }
      } catch(e) {
        console.error("Failed to fetch station reports from Supabase", e);
      }
    };
    
    fetchStationReports();
  }, [stationName]);

  if (!isMounted) return null;

  return (
    <div className="min-h-screen pt-24 pb-32">
      <div className="max-w-4xl mx-auto px-6">
        
        {/* Navigation */}
        <div className="mb-8">
          <button onClick={() => router.back()} className="inline-flex items-center space-x-2 text-xs font-black text-slate-500 uppercase tracking-widest hover:text-indigo-600 transition-colors">
            <ArrowLeft className="w-4 h-4" />
            <span>全国統計に戻る</span>
          </button>
        </div>

        {/* Station Header */}
        <div className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <div className="flex items-center space-x-3 mb-2">
              <MapPin className="w-8 h-8 text-indigo-500" />
              <h1 className="text-4xl font-black text-slate-900 tracking-tighter">{stationName}</h1>
            </div>
            <p className="text-slate-500 font-bold ml-11">市民の証言に基づく、この警察署の個別監査データ</p>
          </div>
        </div>

        {reports.length === 0 ? (
          <div className="glass-card p-16 text-center border-dashed">
            <Info className="w-12 h-12 text-slate-400 mx-auto mb-4" />
            <h3 className="text-xl font-black text-slate-900 mb-2">データがありません</h3>
            <p className="text-slate-500 font-bold mb-8">この警察署に対する監査レポートはまだ投稿されていません。</p>
            <Link href="/report" className="inline-flex items-center justify-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-2xl font-black transition-all shadow-xl text-sm">
              <ShieldAlert className="w-5 h-5" />
              <span>最初のレポートを作成する</span>
            </Link>
          </div>
        ) : (
          <>
            {/* Summary Cards */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-12">
              <div className={`glass-card p-6 border-b-4 ${stationStats.acceptanceRate < 60 ? 'border-b-rose-500 bg-rose-50/30' : 'border-b-emerald-500 bg-emerald-50/30'}`}>
                <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">実効受理率</div>
                <div className="flex items-baseline space-x-2">
                  <span className="text-5xl font-black text-slate-900">{stationStats.acceptanceRate}%</span>
                  {stationStats.acceptanceRate < 60 && <TrendingDown className="w-6 h-6 text-rose-500" />}
                </div>
                <div className="text-[10px] text-slate-400 font-bold mt-2">（受理 {stationStats.resolvedCases}件 / 全 {stationStats.totalReports}件）</div>
              </div>

              <div className="glass-card p-6 border-b-4 border-b-indigo-500 bg-indigo-50/30">
                <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">平均総合スコア</div>
                <div className="flex items-baseline space-x-2">
                  <span className="text-5xl font-black text-slate-900">{stationStats.averageScore}</span>
                  <span className="text-sm font-black text-slate-400">/ 5.0</span>
                </div>
                <div className="flex text-amber-500 mt-2">
                  {[1, 2, 3, 4, 5].map(i => <Zap key={i} size={14} fill={i <= Math.round(stationStats.averageScore) ? "currentColor" : "none"} />)}
                </div>
              </div>

              <div className="glass-card p-6 border-b-4 border-b-amber-500 bg-amber-50/30">
                <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-2">不受理・放置件数</div>
                <div className="text-5xl font-black text-rose-600">{stationStats.totalReports - stationStats.resolvedCases} <span className="text-sm text-slate-500">件</span></div>
                <div className="text-[10px] text-slate-400 font-bold mt-2">監査により検知された不作為数</div>
              </div>
            </div>

            {/* Timeline Area */}
            <div className="space-y-6">
              <div className="flex items-center space-x-3 mb-8">
                <Clock className="w-6 h-6 text-slate-400" />
                <h3 className="text-xl font-black text-slate-900 uppercase tracking-widest">監査レポート・タイムライン</h3>
              </div>

              <div className="space-y-8">
                {reports.map((report, idx) => (
                  <div key={idx} className={`glass-card p-8 border-l-4 relative ${report.problemResolved ? 'border-l-emerald-500 bg-white' : 'border-l-rose-500 bg-rose-50/20'}`}>
                    
                    {/* Timestamp & ID */}
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6 pb-4 border-b border-slate-100">
                      <div className="flex items-center space-x-3">
                        {report.problemResolved ? (
                          <div className="flex items-center space-x-2 text-emerald-600 bg-emerald-50 px-3 py-1 rounded-full border border-emerald-100">
                            <ThumbsUp className="w-4 h-4" />
                            <span className="text-[10px] font-black uppercase tracking-widest">受理・解決</span>
                          </div>
                        ) : (
                          <div className="flex items-center space-x-2 text-rose-600 bg-rose-50 px-3 py-1 rounded-full border border-rose-100">
                            <ThumbsDown className="w-4 h-4" />
                            <span className="text-[10px] font-black uppercase tracking-widest">不受理・放置</span>
                          </div>
                        )}
                        {report.submittedAt && (
                          <span className="text-xs font-bold text-slate-400">
                            投稿: {new Date(report.submittedAt).toLocaleDateString('ja-JP', { year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                          </span>
                        )}
                        {report.incidentYearMonth && (
                          <span className="text-xs font-black text-indigo-600 bg-indigo-50 px-2 py-1 rounded-md border border-indigo-100">
                            相談: {report.incidentYearMonth.split('-')[0]}年{parseInt(report.incidentYearMonth.split('-')[1])}月
                          </span>
                        )}
                      </div>
                      <div className="text-[10px] font-mono font-black text-slate-300 uppercase tracking-widest">
                        ID: {report.caseNumber}
                      </div>
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                      {/* Left Column: Event Details */}
                      <div className="space-y-6">
                        
                        <div>
                          <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-2">事件カテゴリ</div>
                          <div className="flex flex-wrap gap-2">
                            {report.incidentTypes && report.incidentTypes.length > 0 ? (
                              report.incidentTypes.map((type, i) => (
                                <span key={i} className="text-xs font-bold bg-slate-100 text-slate-700 px-3 py-1 rounded-lg border border-slate-200">
                                  {type === 'その他' ? report.otherIncidentType : type}
                                </span>
                              ))
                            ) : (
                              <span className="text-xs font-bold text-slate-400">記録なし</span>
                            )}
                          </div>
                        </div>

                        {!report.problemResolved && (
                          <>
                            <div>
                              <div className="text-[10px] font-black text-rose-500 uppercase tracking-widest mb-2">持参した証拠量</div>
                              <div className="text-sm font-black text-slate-900 border-l-2 border-slate-300 pl-3">
                                {report.evidenceLevel || '記録なし'}
                              </div>
                            </div>
                            
                            <div>
                              <div className="text-[10px] font-black text-rose-500 uppercase tracking-widest mb-2 flex items-center">
                                <AlertOctagon className="w-3 h-3 mr-1" />
                                警察が主張した不受理理由
                              </div>
                              <ul className="list-disc pl-4 space-y-1">
                                {report.denialReasons && report.denialReasons.length > 0 ? (
                                  report.denialReasons.map((reason, i) => (
                                    <li key={i} className="text-xs font-bold text-slate-700">{reason}</li>
                                  ))
                                ) : (
                                  <li className="text-xs font-bold text-slate-400">記録なし</li>
                                )}
                              </ul>
                            </div>
                          </>
                        )}
                      </div>

                      {/* Right Column: Police Evaluation */}
                      <div className="bg-slate-50 p-5 rounded-2xl border border-slate-100">
                        <div className="text-[10px] font-black text-indigo-500 uppercase tracking-widest mb-4 flex items-center border-b border-slate-200 pb-2">
                          <Scale className="w-4 h-4 mr-2" />
                          警察対応評価
                        </div>
                        
                        <div className="space-y-3 mb-6">
                          {[
                            { label: '傾聴姿勢', val: report.evalListening },
                            { label: '法的説明', val: report.evalLegalExplanation },
                            { label: '態度の適切さ', val: report.evalAttitude },
                            { label: '捜査意思', val: report.evalInvestigation },
                            { label: '公平性', val: report.evalFairness }
                          ].map(item => (
                            <div key={item.label} className="flex items-center justify-between">
                              <span className="text-xs font-bold text-slate-600">{item.label}</span>
                              <div className="flex space-x-1">
                                {[1,2,3,4,5].map(v => (
                                  <div key={v} className={`w-4 h-4 rounded-sm ${v <= item.val ? (item.val <= 2 ? 'bg-rose-500' : item.val >= 4 ? 'bg-emerald-500' : 'bg-indigo-500') : 'bg-slate-200'}`}></div>
                                ))}
                              </div>
                            </div>
                          ))}
                        </div>

                        {/* Flags */}
                        <div className="space-y-2 pt-4 border-t border-slate-200">
                          {report.isCivilInterventionRefused === true && (
                            <div className="text-[10px] font-black text-rose-600 bg-rose-100 px-3 py-1.5 rounded-lg">⚠️ 「民事不介入」を理由に拒絶された</div>
                          )}
                          {report.hasSupportProposal === false && (
                            <div className="text-[10px] font-black text-rose-600 bg-rose-100 px-3 py-1.5 rounded-lg">⚠️ サポートや代替案の提案が一切なかった</div>
                          )}
                          {report.isExcellentResponse === true && (
                            <div className="text-[10px] font-black text-emerald-600 bg-emerald-100 px-3 py-1.5 rounded-lg flex items-center">
                              <ThumbsUp className="w-3 h-3 mr-1" /> 優良対応（親身・迅速なサポート）
                            </div>
                          )}
                        </div>
                      </div>
                    </div>

                    {/* Gratitude Comment */}
                    {report.gratitudeComment && (
                      <div className="mt-6 pt-4 border-t border-slate-100">
                        <div className="flex items-start space-x-3 bg-emerald-50 border border-emerald-100 p-4 rounded-xl">
                          <MessageCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
                          <div>
                            <div className="text-[10px] font-black text-emerald-600 uppercase tracking-widest mb-1">市民からの感謝のメッセージ</div>
                            <div className="text-sm font-bold text-slate-700 leading-relaxed">
                              "{report.gratitudeComment}"
                            </div>
                          </div>
                        </div>
                      </div>
                    )}
                    
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

      </div>
    </div>
  );
}
