"use client";

import { useState, useEffect } from 'react';
import { 
  BarChart3, 
  Map as MapIcon, 
  ShieldAlert, 
  TrendingDown, 
  TrendingUp, 
  ChevronRight,
  Scale,
  Search,
  AlertTriangle,
  Zap,
  Info,
  ArrowRight,
  Minus,
  ThumbsUp
} from 'lucide-react';
import Link from 'next/link';
import { AUDIT_STATS } from '../../data/auditStats';
import { REGION_MAP } from '../../data/regions';
import { supabase } from '../../lib/supabaseClient';

export default function AuditStatsPage() {
  const [selectedPref, setSelectedPref] = useState('東京都');
  const [searchQuery, setSearchQuery] = useState('');
  const [dynamicStats, setDynamicStats] = useState(AUDIT_STATS);
  const [evidenceStats, setEvidenceStats] = useState({ many: 0, few: 0, none: 0, total: 0 });
  const [isMounted, setIsMounted] = useState(false);

  useEffect(() => {
    setIsMounted(true);
    
    const fetchReports = async () => {
      try {
        const { data: reports, error } = await supabase.from('reports').select('*');
        if (error) throw error;

        if (reports && reports.length > 0) {
          const newStats = JSON.parse(JSON.stringify(AUDIT_STATS)); // Deep copy
          const newEvidenceStats = { many: 0, few: 0, none: 0, total: 0 };
          
          // Map DB snake_case to frontend camelCase
          const mappedReports = reports.map(r => ({
            caseNumber: r.case_number,
            region: r.region,
            prefecture: r.prefecture,
            policeStation: r.police_station,
            problemResolved: r.problem_resolved,
            evidenceLevel: r.evidence_level,
            incidentTypes: r.incident_types,
            otherIncidentType: r.other_incident_type,
            denialReasons: r.denial_reasons,
            evalListening: r.eval_listening,
            evalLegalExplanation: r.eval_legal_explanation,
            evalAttitude: r.eval_attitude,
            evalInvestigation: r.eval_investigation,
            evalFairness: r.eval_fairness,
            gratitudeComment: r.gratitude_comment,
            submittedAt: new Date(r.submitted_at).getTime()
          }));
          
          mappedReports.forEach(report => {
          const pref = report.prefecture || "不明";
          if (!pref) return;

          // Initialize prefecture if not exists
          if (!newStats[pref]) {
            newStats[pref] = { acceptanceRate: 0, totalReports: 0, stations: [] };
          }
          
          newStats[pref].totalReports += 1;

          // Update Station
          const safeStationName = report.policeStation || "未入力（警察署不明）";
          let station = newStats[pref].stations.find(s => s.name === safeStationName);
          if (!station) {
            station = {
              name: safeStationName,
              reports: 0,
              resolvedCases: 0,
              initialScore: 0,
              resolutionScore: 0,
              score: 0,
              cautionCrimes: [],
              gratitudeComments: []
            };
            newStats[pref].stations.push(station);
          }

          station.reports += 1;
          if (report.problemResolved === true) {
            station.resolvedCases += 1;
          } else {
            // Unaccepted cases: Aggregate Evidence Levels
            if (report.evidenceLevel) {
              if (report.evidenceLevel === 1 || report.evidenceLevel === '多数の証拠') newEvidenceStats.many += 1;
              else if (report.evidenceLevel === 2 || report.evidenceLevel === '少数の証拠') newEvidenceStats.few += 1;
              else if (report.evidenceLevel === 3 || report.evidenceLevel === '証拠なし') newEvidenceStats.none += 1;
              newEvidenceStats.total += 1;
            }

            // For unaccepted cases, increment cautionCrimes
            if (report.incidentTypes && Array.isArray(report.incidentTypes)) {
              report.incidentTypes.forEach(type => {
                const crimeName = type === 'その他' && report.otherIncidentType ? report.otherIncidentType.trim() : type;
                if (!crimeName) return;
                
                const crimeIndex = station.cautionCrimes.findIndex(c => c.name === crimeName);
                if (crimeIndex >= 0) {
                  station.cautionCrimes[crimeIndex].count += 1;
                } else {
                  station.cautionCrimes.push({ name: crimeName, count: 1 });
                }
              });
            } else if (report.incidentType) {
              // Backwards compatibility for older reports
              const crimeName = report.incidentType === 'その他' && report.otherIncidentType ? report.otherIncidentType.trim() : report.incidentType;
              if (crimeName) {
                const crimeIndex = station.cautionCrimes.findIndex(c => c.name === crimeName);
                if (crimeIndex >= 0) {
                  station.cautionCrimes[crimeIndex].count += 1;
                } else {
                  station.cautionCrimes.push({ name: crimeName, count: 1 });
                }
              }
            }
          }

          // Update Score (Average)
          const reportScore = (report.evalListening + report.evalLegalExplanation + report.evalAttitude + report.evalInvestigation + report.evalFairness) / 5;
          if (!isNaN(reportScore) && reportScore > 0) {
             const prevTotal = station.score * (station.reports - 1);
             station.score = (prevTotal + reportScore) / station.reports;
             station.score = Math.round(station.score * 10) / 10;
          }

          // Add gratitude comment if exists
          if (report.gratitudeComment && typeof report.gratitudeComment === 'string' && report.gratitudeComment.trim() !== '') {
            station.gratitudeComments.push(report.gratitudeComment.trim());
          }

          // Recalculate Acceptance Rate for the Prefecture
          const totalPrefResolved = newStats[pref].stations.reduce((acc, s) => acc + s.resolvedCases, 0);
          newStats[pref].acceptanceRate = Math.round((totalPrefResolved / newStats[pref].totalReports) * 100) || 0;
        });

        setDynamicStats(newStats);
        setEvidenceStats(newEvidenceStats);
        }
      } catch(e) {
        console.error("Failed to fetch reports from Supabase", e);
      }
    };
    
    fetchReports();
  }, []);

  const stats = dynamicStats[selectedPref] || { acceptanceRate: 0, stations: [], totalReports: 0 };

  // 全国未受理犯罪の集計
  const nationalCrimeAgg = {};
  let totalNationalReports = 0;
  let totalNationalResolved = 0;

  Object.values(dynamicStats).forEach(pref => {
    totalNationalReports += pref.totalReports;
    totalNationalResolved += Math.round(pref.totalReports * (pref.acceptanceRate / 100));
    
    pref.stations.forEach(station => {
      if (station.cautionCrimes) {
        station.cautionCrimes.forEach(crime => {
          if (nationalCrimeAgg[crime.name]) {
            nationalCrimeAgg[crime.name] += crime.count;
          } else {
            nationalCrimeAgg[crime.name] = crime.count;
          }
        });
      }
    });
  });

  const nationalCrimesList = Object.entries(nationalCrimeAgg)
    .map(([name, count]) => ({ name, count }))
    .sort((a, b) => b.count - a.count);

  const totalNationalCautionCrimes = nationalCrimesList.reduce((acc, curr) => acc + curr.count, 0);
  const nationalAcceptanceRate = totalNationalReports > 0 ? ((totalNationalResolved / totalNationalReports) * 100).toFixed(1) : 0;

  if (!isMounted) return null; // Avoid hydration mismatch

  return (
    <div className="min-h-screen pt-24 pb-32">
      <div className="max-w-6xl mx-auto px-6">
        
        {/* Header */}
        <div className="mb-12 flex flex-col md:flex-row md:items-end justify-between gap-6">
          <div>
            <div className="flex items-center space-x-4 mb-2">
              <BarChart3 className="w-10 h-10 text-indigo-500" />
              <h1 className="text-4xl font-black text-slate-900 tracking-tighter uppercase">National Audit Stats</h1>
            </div>
            <p className="text-slate-500 font-bold">市民の証言に基づく、公的機関の「受理率」と「信頼性」の統計</p>
          </div>

          <div className="flex items-center space-x-4 bg-white p-2 rounded-2xl border border-slate-200 shadow-sm">
            <div className="px-6 py-3 border-r border-slate-200 text-center">
              <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">全国平均受理率</div>
              <div className="text-2xl font-black text-emerald-500">{nationalAcceptanceRate}%</div>
            </div>
            <div className="px-6 py-3 text-center">
              <div className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">総監査レポート数</div>
              <div className="text-2xl font-black text-slate-900">{totalNationalReports}</div>
            </div>
          </div>
        </div>

        {/* 全国の不受理傾向分析（カテゴリ内訳 ＆ 証拠の有無） */}
        <div className="mb-8 glass-card p-8 md:p-10 border-indigo-200 bg-indigo-50/80 space-y-12">
          
          {/* 上段：未受理犯罪カテゴリ内訳 */}
          <div>
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
              <h3 className="text-sm font-black text-indigo-600 uppercase tracking-widest flex items-center">
                <AlertTriangle className="w-5 h-5 mr-3" />
                全国 未受理犯罪カテゴリ内訳
              </h3>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tighter bg-white/50 px-3 py-1 rounded-full">※全国の監査で報告された不受理事案の割合</p>
            </div>
            
            {/* 積み上げバー */}
            <div className="w-full h-8 bg-slate-200 rounded-full overflow-hidden flex mb-6 shadow-inner border border-slate-300">
              {nationalCrimesList.length > 0 ? nationalCrimesList.map((crime, idx) => {
                const percentage = totalNationalCautionCrimes > 0 ? ((crime.count / totalNationalCautionCrimes) * 100).toFixed(1) : 0;
                const COLORS = ['bg-indigo-600', 'bg-purple-500', 'bg-blue-500', 'bg-emerald-500', 'bg-amber-500', 'bg-orange-500', 'bg-slate-500'];
                const colorClass = COLORS[idx % COLORS.length];
                return (
                  <div 
                    key={crime.name} 
                    className={`h-full transition-all duration-1000 ${colorClass} hover:opacity-90 cursor-default border-r border-white/20 last:border-r-0`}
                    style={{ width: `${percentage}%` }}
                    title={`${crime.name}: ${percentage}% (${crime.count}件)`}
                  ></div>
                );
              }) : (
                <div className="w-full h-full bg-slate-300 flex items-center justify-center text-[10px] text-white font-bold">データなし</div>
              )}
            </div>

            {/* 凡例（Legend） */}
            <div className="flex flex-wrap justify-center gap-3">
              {nationalCrimesList.map((crime, idx) => {
                const percentage = totalNationalCautionCrimes > 0 ? ((crime.count / totalNationalCautionCrimes) * 100).toFixed(1) : 0;
                const COLORS = ['bg-indigo-600', 'bg-purple-500', 'bg-blue-500', 'bg-emerald-500', 'bg-amber-500', 'bg-orange-500', 'bg-slate-500'];
                const colorClass = COLORS[idx % COLORS.length];
                return (
                  <div key={crime.name} className="flex items-center space-x-2 bg-white px-4 py-2 rounded-xl border border-slate-100 shadow-sm transition-all hover:shadow-md hover:-translate-y-0.5">
                    <span className={`w-3 h-3 rounded-full ${colorClass}`}></span>
                    <span className="text-xs font-black text-slate-700">{crime.name}</span>
                    <div className="flex items-baseline space-x-1 ml-2 pl-2 border-l border-slate-100">
                      <span className="text-sm font-black text-slate-900">{percentage}%</span>
                      <span className="text-[10px] font-bold text-slate-400">({crime.count}件)</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* 下段：証拠の有無と不受理の関係 */}
          <div className="pt-10 border-t border-indigo-200/60">
            <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 gap-4">
              <h3 className="text-sm font-black text-rose-600 uppercase tracking-widest flex items-center">
                <Scale className="w-5 h-5 mr-3" />
                不受理とされたケースの証拠量
              </h3>
              <p className="text-[10px] text-slate-500 font-bold uppercase tracking-tighter bg-white/50 px-3 py-1 rounded-full">※不受理とされたケースにおいて、持参されていた証拠の量</p>
            </div>

            {/* 積み上げバー */}
            <div className="w-full h-8 bg-slate-200 rounded-full overflow-hidden flex mb-6 shadow-inner border border-slate-300">
              {evidenceStats.total > 0 ? (
                <>
                  <div className="h-full bg-rose-600 transition-all duration-1000 hover:opacity-90 cursor-default border-r border-white/20" style={{ width: `${(evidenceStats.many / evidenceStats.total) * 100}%` }} title={`多数の証拠: ${((evidenceStats.many / evidenceStats.total) * 100).toFixed(1)}%`}></div>
                  <div className="h-full bg-amber-500 transition-all duration-1000 hover:opacity-90 cursor-default border-r border-white/20" style={{ width: `${(evidenceStats.few / evidenceStats.total) * 100}%` }} title={`少数の証拠: ${((evidenceStats.few / evidenceStats.total) * 100).toFixed(1)}%`}></div>
                  <div className="h-full bg-slate-400 transition-all duration-1000 hover:opacity-90 cursor-default" style={{ width: `${(evidenceStats.none / evidenceStats.total) * 100}%` }} title={`証拠なし: ${((evidenceStats.none / evidenceStats.total) * 100).toFixed(1)}%`}></div>
                </>
              ) : (
                <div className="w-full h-full bg-slate-300 flex items-center justify-center text-[10px] text-white font-bold">データなし</div>
              )}
            </div>

            {/* 凡例 */}
            <div className="flex flex-wrap justify-center gap-3">
              {[
                { label: '多数の証拠を持参', count: evidenceStats.many, color: 'bg-rose-600' },
                { label: '少数の証拠を持参', count: evidenceStats.few, color: 'bg-amber-500' },
                { label: '証拠なし', count: evidenceStats.none, color: 'bg-slate-400' }
              ].map(item => {
                const percentage = evidenceStats.total > 0 ? ((item.count / evidenceStats.total) * 100).toFixed(1) : 0;
                return (
                  <div key={item.label} className="flex items-center space-x-2 bg-white px-4 py-2 rounded-xl border border-rose-100 shadow-sm transition-all hover:shadow-md hover:-translate-y-0.5">
                    <span className={`w-3 h-3 rounded-full ${item.color}`}></span>
                    <span className="text-xs font-black text-slate-700">{item.label}</span>
                    <div className="flex items-baseline space-x-1 ml-2 pl-2 border-l border-slate-100">
                      <span className="text-sm font-black text-slate-900">{percentage}%</span>
                      <span className="text-[10px] font-bold text-slate-400">({item.count}件)</span>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* 2. 次に都道府県を選び、その隣に都道府県の監査状況 */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 mb-8">
          
          {/* 左側：都道府県を選択 */}
          <div className="lg:col-span-4">
            <div className="glass-card p-6 h-full flex flex-col">
              <h3 className="text-xs font-black text-slate-900 uppercase tracking-widest mb-6 flex items-center shrink-0">
                <MapIcon className="w-4 h-4 mr-2 text-indigo-500" />
                都道府県を選択
              </h3>
              
              <div className="space-y-2 flex-1 overflow-y-auto pr-2 custom-scrollbar" style={{ maxHeight: '400px' }}>
                {Object.keys(REGION_MAP).map(region => (
                  <div key={region} className="space-y-1 mb-4">
                    <div className="text-[9px] font-black text-slate-400 uppercase tracking-widest pl-2 mb-2">{region}</div>
                    {REGION_MAP[region].map(pref => {
                      const prefData = dynamicStats[pref];
                      return (
                        <button
                          key={pref}
                          onClick={() => setSelectedPref(pref)}
                          className={`w-full flex items-center justify-between px-4 py-3 rounded-xl text-xs font-bold transition-all ${selectedPref === pref ? 'bg-indigo-600 text-white shadow-lg' : 'bg-white text-slate-600 hover:bg-slate-100 border border-slate-200'}`}
                        >
                          <span>{pref}</span>
                          {prefData && (
                            <span className={`text-[9px] px-1.5 py-0.5 rounded ${prefData.acceptanceRate < 60 ? 'bg-rose-100 text-rose-600' : 'bg-emerald-100 text-emerald-600'}`}>
                              {prefData.acceptanceRate}%
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                ))}
              </div>
            </div>
          </div>

          {/* 右側：都道府県の監査状況 */}
          <div className="lg:col-span-8">
            <div className="glass-card p-10 relative overflow-hidden h-full flex flex-col justify-center">
              <div className="absolute top-0 right-0 p-8 opacity-5 pointer-events-none">
                <Scale className="w-48 h-48 text-indigo-900" />
              </div>
              
              <div className="relative z-10">
                <div className="flex items-center justify-between mb-10">
                  <div className="flex items-center space-x-4">
                    <h2 className="text-4xl font-black text-slate-900 tracking-tighter uppercase">{selectedPref} 監査概況</h2>
                    <div className={`px-4 py-1.5 rounded-full text-xs font-black uppercase shadow-sm border ${stats.acceptanceRate < 60 ? 'bg-rose-50 text-rose-600 border-rose-200' : 'bg-emerald-50 text-emerald-600 border-emerald-200'}`}>
                      {stats.acceptanceRate < 60 ? 'High Unresolved Density' : 'Operational'}
                    </div>
                  </div>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-3 gap-8">
                  <div className="space-y-3">
                    <div className="text-xs font-black text-slate-500 uppercase tracking-widest">実効受理率</div>
                    <div className="flex items-baseline space-x-2">
                      <span className="text-6xl font-black text-slate-900">{stats.acceptanceRate}%</span>
                      {stats.acceptanceRate < 65 && <TrendingDown className="w-6 h-6 text-rose-500" />}
                    </div>
                    <div className="w-full bg-slate-200 h-2.5 rounded-full overflow-hidden mt-4">
                      <div className="bg-indigo-500 h-full transition-all duration-1000" style={{ width: `${stats.acceptanceRate}%` }}></div>
                    </div>
                  </div>
                  
                  <div className="sm:border-l sm:border-slate-200 sm:pl-8 space-y-3">
                    <div className="text-xs font-black text-rose-500 uppercase tracking-widest">不受理・あしらい件数</div>
                    <div className="text-5xl font-black text-slate-900">{(stats.totalReports * (1 - stats.acceptanceRate/100)).toFixed(0)} <span className="text-sm text-slate-500">件</span></div>
                    <div className="text-[10px] text-slate-400 font-bold uppercase mt-2">監査により検知された不作為の総数</div>
                  </div>

                  <div className="sm:border-l sm:border-slate-200 sm:pl-8 space-y-3">
                    <div className="text-xs font-black text-slate-500 uppercase tracking-widest">平均評価スコア</div>
                    <div className="flex items-baseline space-x-2">
                      <span className="text-5xl font-black text-slate-900">{((stats.stations || []).reduce((acc, s) => acc + (s.score || 0), 0) / (stats.stations?.length || 1)).toFixed(1)}</span>
                      <span className="text-lg text-slate-400 font-bold">/ 5.0</span>
                    </div>
                    <div className="flex text-amber-500 mt-2">
                      {[1, 2, 3, 4, 5].map(i => <Zap key={i} size={16} fill={i <= 3 ? "currentColor" : "none"} />)}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* 3. 各警察署の詳細を横いっぱい使う */}
        <div className="mb-12 space-y-6">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 px-2">
            <h3 className="text-lg font-black text-slate-900 uppercase tracking-widest flex items-center">
              <ShieldAlert className="w-6 h-6 mr-3 text-rose-500" />
              {selectedPref}内 警察署別分析データ
            </h3>
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400" />
              <input 
                type="text" 
                placeholder="警察署を検索..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="bg-white border border-slate-200 rounded-xl pl-10 pr-4 py-2.5 text-xs font-bold text-slate-900 outline-none focus:border-indigo-400 focus:ring-1 focus:ring-indigo-400 shadow-sm w-full sm:w-64"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {stats.stations.filter(s => (s.name || '').includes(searchQuery)).length > 0 ? stats.stations.filter(s => (s.name || '').includes(searchQuery)).map((station) => (
              <div key={station.name} className="glass-card p-6 group hover:border-indigo-300 transition-all shadow-sm bg-white flex flex-col h-full">
                <div className="flex flex-col space-y-4 flex-grow">
                  
                  {/* ヘッダー部分 */}
                  <div className="flex items-start justify-between border-b border-slate-100 pb-4">
                    <div className="space-y-2">
                      <h4 className="text-xl font-black text-slate-900">{station.name}</h4>
                      <div className="flex flex-wrap items-center gap-2">
                        {/* 解決率 */}
                        <span className="text-[10px] px-2 py-1 bg-indigo-50 text-indigo-700 rounded-md font-black border border-indigo-100">
                          解決率: {station.reports > 0 ? Math.round(((station.resolvedCases || 0) / station.reports) * 100) : 0}%
                        </span>
                        {/* スコアバッジ */}
                        <div className="flex items-center space-x-1 px-2 py-1 bg-slate-50 rounded-md border border-slate-200">
                          <span className="text-[9px] font-black text-slate-500 uppercase">総合</span>
                          <span className={`text-[11px] font-black ${station.score < 2.5 ? 'text-rose-600' : 'text-emerald-600'}`}>
                            {station.score}
                          </span>
                        </div>
                      </div>
                    </div>
                    <div className="text-right flex flex-col items-end">
                      <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">評価推移 (初動→解決)</div>
                      <div className="flex items-center space-x-1 px-3 py-1.5 bg-slate-50 rounded-lg border border-slate-200 shadow-inner">
                        <span className="text-xs font-black text-slate-700">{station.initialScore || station.score}</span>
                        <ArrowRight className="w-3 h-3 text-slate-400 mx-1" />
                        <span className={`text-xs font-black ${station.resolutionScore > (station.initialScore || station.score) ? 'text-emerald-600' : station.resolutionScore < (station.initialScore || station.score) ? 'text-rose-600' : 'text-slate-700'}`}>{station.resolutionScore || station.score}</span>
                        {station.resolutionScore > (station.initialScore || station.score) ? (
                          <TrendingUp className="w-3.5 h-3.5 text-emerald-500 ml-1" />
                        ) : station.resolutionScore < (station.initialScore || station.score) ? (
                          <TrendingDown className="w-3.5 h-3.5 text-rose-500 ml-1" />
                        ) : (
                          <Minus className="w-3.5 h-3.5 text-slate-400 ml-1" />
                        )}
                      </div>
                    </div>
                  </div>

                  {/* 事案別データ */}
                  <div className="pt-2">
                    <div className="flex items-center space-x-2 mb-3">
                      <AlertTriangle className="w-3.5 h-3.5 text-rose-500" />
                      <span className="text-[10px] font-black text-slate-600 uppercase tracking-widest">不受理・放置された事案の内訳</span>
                    </div>
                    <div className="flex flex-wrap gap-2">
                      {station.cautionCrimes && station.cautionCrimes.length > 0 ? station.cautionCrimes.map(crime => (
                        <div key={crime.name} className="flex items-center justify-between text-[10px] bg-rose-50 border border-rose-100 rounded-lg px-3 py-1.5 min-w-[120px]">
                          <span className="font-bold text-rose-700">{crime.name}</span>
                          <span className="font-black text-rose-600 bg-white px-2 py-0.5 rounded shadow-sm">{crime.count} 件</span>
                        </div>
                      )) : (
                        <div className="text-[10px] text-slate-400 font-bold">データなし</div>
                      )}
                    </div>
                  </div>

                  {/* 市民からの感謝の声 (あれば表示) */}
                  {station.gratitudeComments && station.gratitudeComments.length > 0 && (
                    <div className="pt-4 border-t border-slate-100 mt-2">
                      <div className="flex items-center space-x-2 mb-3">
                        <ThumbsUp className="w-3.5 h-3.5 text-emerald-500" />
                        <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">市民からの感謝の声（優良対応）</span>
                      </div>
                      <div className="space-y-2 max-h-32 overflow-y-auto custom-scrollbar pr-2">
                        {station.gratitudeComments.map((comment, i) => (
                          <div key={i} className="text-[11px] font-bold text-slate-600 bg-emerald-50/50 p-3 rounded-lg border border-emerald-100/50 leading-relaxed">
                            "{comment}"
                          </div>
                        ))}
                      </div>
                    </div>
                  )}

                </div>

                {/* 詳細ページへのリンク */}
                <div className="pt-4 mt-4 border-t border-slate-100 flex justify-end">
                  <Link href={`/station/${encodeURIComponent(station.name)}`} className="inline-flex items-center space-x-1 text-[11px] font-black text-indigo-600 hover:text-indigo-800 transition-colors uppercase tracking-widest bg-indigo-50 hover:bg-indigo-100 px-3 py-1.5 rounded-lg border border-indigo-100/50">
                    <span>この警察署の詳細・過去のレポートを見る</span>
                    <ArrowRight className="w-3 h-3" />
                  </Link>
                </div>
              </div>
            )) : (
                <div className="lg:col-span-2 py-20 text-center glass-card border-dashed">
                  <Info className="w-12 h-12 text-slate-400 mx-auto mb-4" />
                  <p className="text-slate-500 font-bold">該当する警察署データは見つかりませんでした</p>
                </div>
            )}
          </div>
        </div>

        {/* ランキングセクション (ワースト ＆ トップ) */}
        <div className="mb-16 grid grid-cols-1 lg:grid-cols-2 gap-8">
          
          {/* ワースト3 (不受理) */}
          <div className="glass-card p-8 border-rose-200 bg-rose-50/50 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-6 opacity-10 pointer-events-none">
              <TrendingDown className="w-40 h-40 text-rose-500" />
            </div>
            <div className="relative z-10">
              <h3 className="text-lg font-black text-rose-600 uppercase tracking-widest mb-2 flex items-center">
                <TrendingDown className="w-6 h-6 mr-3" />
                不受理数 全国ワースト3
              </h3>
              <p className="text-[10px] text-slate-500 font-bold mb-6">※監査データから算出された、不当な門前払いが検知された総数</p>
              
              <div className="space-y-4">
                {Object.entries(dynamicStats)
                  .map(([name, data]) => ({ name, rejected: Math.round(data.totalReports * (1 - data.acceptanceRate/100)) }))
                  .sort((a, b) => b.rejected - a.rejected)
                  .slice(0, 3)
                  .map((pref, idx) => (
                    <div key={pref.name} className="bg-white p-5 rounded-2xl border border-rose-100 shadow-sm flex items-center justify-between transition-all hover:shadow-md hover:-translate-y-0.5">
                      <div className="flex items-center space-x-4">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-black text-white text-lg shadow-inner ${idx === 0 ? 'bg-rose-600' : idx === 1 ? 'bg-rose-500' : 'bg-rose-400'}`}>
                          {idx + 1}
                        </div>
                        <span className="text-base font-black text-slate-900">{pref.name}</span>
                      </div>
                      <div className="text-right">
                        <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">不受理・あしらい件数</div>
                        <div className="text-2xl font-black text-rose-600">{pref.rejected} <span className="text-xs text-slate-500">件</span></div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>

          {/* トップ3 (受理率) */}
          <div className="glass-card p-8 border-emerald-200 bg-emerald-50/50 relative overflow-hidden">
            <div className="absolute top-0 right-0 p-6 opacity-10 pointer-events-none">
              <TrendingUp className="w-40 h-40 text-emerald-500" />
            </div>
            <div className="relative z-10">
              <h3 className="text-lg font-black text-emerald-600 uppercase tracking-widest mb-2 flex items-center">
                <TrendingUp className="w-6 h-6 mr-3" />
                優良対応 (高受理率) トップ3
              </h3>
              <p className="text-[10px] text-slate-500 font-bold mb-6">※市民の訴えを真摯に受け止め、適切に受理・対応した割合</p>
              
              <div className="space-y-4">
                {Object.entries(dynamicStats)
                  .map(([name, data]) => ({ name, rate: data.acceptanceRate, total: data.totalReports }))
                  .filter(data => data.total > 0)
                  .sort((a, b) => b.rate - a.rate)
                  .slice(0, 3)
                  .map((pref, idx) => (
                    <div key={pref.name} className="bg-white p-5 rounded-2xl border border-emerald-100 shadow-sm flex items-center justify-between transition-all hover:shadow-md hover:-translate-y-0.5">
                      <div className="flex items-center space-x-4">
                        <div className={`w-10 h-10 rounded-full flex items-center justify-center font-black text-white text-lg shadow-inner ${idx === 0 ? 'bg-emerald-600' : idx === 1 ? 'bg-emerald-500' : 'bg-emerald-400'}`}>
                          {idx + 1}
                        </div>
                        <span className="text-base font-black text-slate-900">{pref.name}</span>
                      </div>
                      <div className="text-right">
                        <div className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-0.5">実効受理率</div>
                        <div className="text-2xl font-black text-emerald-600">{pref.rate}%</div>
                      </div>
                    </div>
                  ))}
              </div>
            </div>
          </div>
          
        </div>

        {/* CTA: Report Creation Banner */}
        <div className="mt-16 glass-card p-10 flex flex-col md:flex-row items-center justify-between gap-8 border-indigo-200 bg-indigo-50">
          <div className="space-y-3">
            <div className="text-xs font-black text-indigo-600 uppercase tracking-widest">あなたの証言が統計を変える</div>
            <h3 className="text-3xl font-black text-slate-900 tracking-tighter">警察対応を公正に評価する</h3>
            <p className="text-slate-600 font-bold text-sm leading-relaxed max-w-xl">
              レポートを送信することで、この統計データに反映され、社会の死角を明らかにします。<br/>
              警察署ごとの「受理率」と「信頼性」を市民の手で透明化しましょう。
            </p>
          </div>
          <Link
            href="/report"
            className="shrink-0 inline-flex items-center space-x-3 bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-5 rounded-2xl font-black transition-all uppercase tracking-widest text-sm shadow-xl shadow-indigo-600/20 hover:-translate-y-1"
          >
            <ShieldAlert className="w-6 h-6" />
            <span>監査レポートを作成</span>
            <ChevronRight className="w-5 h-5" />
          </Link>
        </div>

        {/* Legal Knowledge Base */}
        <div className="mt-8 glass-card p-8 border-slate-200 bg-white shadow-sm">
          <h3 className="text-sm font-black text-slate-900 uppercase tracking-widest flex items-center mb-4 pb-4 border-b border-slate-100">
            <Info className="w-5 h-5 mr-3 text-indigo-500" />
            知っておくべき法的権利：警察の「受理義務」とは
          </h3>
          <div className="text-xs text-slate-600 font-bold leading-relaxed space-y-4">
            <p>
              実は、国家公安委員会の定める「犯罪捜査規範（第61条・第63条）」により、警察には市民からの被害届や告訴状を<strong className="text-slate-900 border-b border-emerald-300">原則として受理する義務</strong>があります。
              「証拠が足りない」「管轄外だ」といった理由で窓口で被害届を突き返すことは、本来ルール違反とされています。
            </p>
            <p>
              正当に受理を拒否できるのは、以下のような「例外的なケース」のみです。
            </p>
            <ul className="list-disc pl-5 space-y-1 text-slate-500">
              <li>客観的に見て明らかに犯罪事実がない場合（虚偽・勘違いなど）</li>
              <li>完全に民事上のトラブルであり、刑事事件の要件を満たさない場合（真の民事不介入）</li>
              <li>すでに公訴時効が成立している場合</li>
            </ul>
            <div className="p-4 bg-rose-50 border border-rose-100 rounded-xl mt-2">
              <p className="text-rose-700">
                <strong className="font-black">なぜ不受理（門前払い）が起きるのか？</strong><br/>
                現実の交番や窓口では、「証拠がない」「当事者同士で解決して」と言いくるめて被害届を受け取らないケースが後を絶ちません。
                これは警察組織の内部事情（人員不足や捜査ノルマ）による不当な「あしらい」である可能性が高いです。<br/>
                当プラットフォームは、このような<strong className="underline">「不当な不受理による不作為」</strong>を客観的データとして可視化し、警察に本来の義務を果たさせるための社会的な監査システムです。
              </p>
            </div>
          </div>
        </div>

      </div>
    </div>
  );
}
