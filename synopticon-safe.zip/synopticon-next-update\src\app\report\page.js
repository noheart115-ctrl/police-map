"use client";

import { useState, useEffect } from 'react';
import { 
  ShieldAlert,
  MapPin, 
  Scale, 
  ClipboardCheck, 
  CheckCircle, 
  ArrowRight,
  ShieldCheck,
  AlertOctagon,
  ThumbsDown,
  ThumbsUp,
  ChevronRight,
  BarChart3,
  FileText,
  Clock
} from 'lucide-react';
import Link from 'next/link';
import { REGION_MAP } from '../../data/regions';
import { supabase } from '../../lib/supabaseClient';

const INCIDENT_CATEGORIES = [
  '騒音問題',
  '違法駐車・交通トラブル',
  '窃盗・万引き・空き巣',
  '暴行・傷害',
  '器物損壊',
  'ストーカー・DV',
  '性的被害',
  '近隣トラブル',
  '金銭トラブル・詐欺',
  'ネット誹謗・中傷',
  '外国人問題',
  'その他'
];

export default function PoliceAuditReport() {
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    caseNumber: '',
    incidentYearMonth: '',
    region: '',
    prefecture: '',
    policeStation: '',
    problemResolved: null, // true=受理された, false=不受理・放置された
    
    // STEP 2: 不受理詳細 (スキップ可能)
    evidenceLevel: '', // ① 証拠の有無・量 ('多数の証拠', '少数の証拠', '証拠なし')
    incidentTypes: [], // ② 事件カテゴリ
    otherIncidentType: '', 
    denialReasons: [], // ③ 不受理理由
    
    // STEP 3: 警察対応評価
    evalListening: 0,
    evalLegalExplanation: 0,
    evalAttitude: 0,
    evalInvestigation: 0,
    evalFairness: 0,
    hasCaseNumber: null,
    hasGuidelineExplanation: null,
    isCivilInterventionRefused: null,
    hasSupportProposal: null, // 具体的なサポートの提案
    isExcellentResponse: null, // 追加: 優良対応フラグ

    // STEP 4: コメント・送信
    gratitudeComment: '', // 追加: 感謝の声
    comments: '',
    isSubmitted: false
  });

  const [hasAgreed, setHasAgreed] = useState(false);
  const [isRateLimited, setIsRateLimited] = useState(false);
  const [timeRemaining, setTimeRemaining] = useState('');

  useEffect(() => {
    const lastReportTime = localStorage.getItem('lastReportTime');
    if (lastReportTime) {
      const elapsed = Date.now() - parseInt(lastReportTime, 10);
      const limit = 24 * 60 * 60 * 1000;
      if (elapsed < limit) {
        setIsRateLimited(true);
        const remainingMs = limit - elapsed;
        const hours = Math.floor(remainingMs / (1000 * 60 * 60));
        const mins = Math.floor((remainingMs % (1000 * 60 * 60)) / (1000 * 60));
        setTimeRemaining(`${hours}時間${mins}分`);
      }
    }
  }, []);

  const generateCaseNumber = () => {
    const year = new Date().getFullYear();
    const rand = Math.random().toString(36).substring(2, 8).toUpperCase();
    return `KPM-${year}-${rand}`;
  };

  // 動的ルーティングのロジック
  const nextStep = () => {
    if (step === 1 && formData.problemResolved === true) {
      // 受理された場合はSTEP 2をスキップしてSTEP 3へ
      setStep(3);
    } else {
      setStep(prev => Math.min(prev + 1, 4));
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const prevStep = () => {
    if (step === 3 && formData.problemResolved === true) {
      // 受理された場合はSTEP 2をスキップしてSTEP 1へ戻る
      setStep(1);
    } else {
      setStep(prev => Math.max(prev - 1, 1));
    }
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleRating = (key, val) => {
    setFormData(prev => ({ ...prev, [key]: val }));
  };

  const handleIncidentTypeToggle = (type) => {
    setFormData(prev => {
      const types = [...prev.incidentTypes];
      if (types.includes(type)) {
        return { ...prev, incidentTypes: types.filter(t => t !== type) };
      } else {
        return { ...prev, incidentTypes: [...types, type] };
      }
    });
  };

  const handleDenialReasonToggle = (reason) => {
    setFormData(prev => {
      const reasons = [...prev.denialReasons];
      if (reasons.includes(reason)) {
        return { ...prev, denialReasons: reasons.filter(r => r !== reason) };
      } else {
        return { ...prev, denialReasons: [...reasons, reason] };
      }
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const newCaseNumber = generateCaseNumber();
    const initialScore = (formData.evalListening + formData.evalLegalExplanation + formData.evalAttitude + formData.evalInvestigation + formData.evalFairness) / 5;
    
    const finalPoliceStation = formData.policeStation.endsWith('警察署') 
      ? formData.policeStation 
      : `${formData.policeStation}警察署`;

    const submissionData = { 
      case_number: newCaseNumber,
      incident_year_month: formData.incidentYearMonth,
      region: formData.region,
      prefecture: formData.prefecture,
      police_station: finalPoliceStation,
      problem_resolved: formData.problemResolved,
      evidence_level: formData.evidenceLevel,
      incident_types: formData.incidentTypes,
      other_incident_type: formData.otherIncidentType,
      denial_reasons: formData.denialReasons,
      eval_listening: formData.evalListening,
      eval_legal_explanation: formData.evalLegalExplanation,
      eval_attitude: formData.evalAttitude,
      eval_investigation: formData.evalInvestigation,
      eval_fairness: formData.evalFairness,
      has_case_number: formData.hasCaseNumber,
      has_guideline_explanation: formData.hasGuidelineExplanation,
      is_civil_intervention_refused: formData.isCivilInterventionRefused,
      has_support_proposal: formData.hasSupportProposal,
      is_excellent_response: formData.isExcellentResponse,
      gratitude_comment: formData.gratitudeComment,
      initial_score: initialScore
    };

    try {
      const { error } = await supabase.from('reports').insert([submissionData]);
      if (error) throw error;

      setFormData({ ...formData, caseNumber: newCaseNumber, isSubmitted: true });
      
      const now = Date.now();
      localStorage.setItem('lastReportTime', now.toString());
      localStorage.setItem(`kpm_case_${newCaseNumber}`, now.toString());
      
      window.scrollTo({ top: 0, behavior: 'smooth' });
    } catch (err) {
      console.error("Failed to submit report to Supabase:", err);
      alert("通信エラーが発生しました。時間をおいて再度お試しください。");
    }
  };

  if (isRateLimited) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="max-w-2xl w-full glass-card p-12 text-center animate-in zoom-in duration-500">
          <div className="w-24 h-24 bg-rose-100 rounded-full flex items-center justify-center mx-auto mb-8">
            <AlertOctagon className="w-12 h-12 text-rose-600" />
          </div>
          <h2 className="text-3xl font-black text-slate-900 mb-4 tracking-tighter uppercase">投稿制限中</h2>
          <p className="text-slate-500 font-medium mb-8 leading-relaxed">
            スパムや不正な評価操作を防ぐため、同一デバイスからの監査レポート提出は<strong className="text-slate-900">24時間に1回</strong>に制限されています。<br/>
            次回の報告が可能になるまで、あと <strong className="text-rose-600">{timeRemaining}</strong> お待ちください。
          </p>
          <Link href="/stats" className="inline-flex items-center space-x-2 bg-slate-100 hover:bg-slate-200 text-slate-900 px-8 py-4 rounded-2xl font-black transition-all uppercase tracking-widest text-sm border border-slate-200">
            全国統計を見る
          </Link>
        </div>
      </div>
    );
  }

  if (formData.isSubmitted) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6">
        <div className="max-w-2xl w-full glass-card p-12 text-center animate-in zoom-in duration-500">
          <div className="w-24 h-24 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-8">
            <ShieldCheck className="w-12 h-12 text-emerald-600" />
          </div>
          
          {formData.problemResolved === false && (
            <div className="mb-8 p-4 bg-rose-50 border border-rose-200 rounded-2xl inline-block w-full max-w-md">
              <div className="flex items-center justify-center space-x-2 mb-2">
                <AlertOctagon className="w-4 h-4 text-rose-600" />
                <span className="text-[10px] font-black text-rose-600 uppercase tracking-widest">Tracking Issued</span>
              </div>
              <h3 className="text-sm font-bold text-slate-700 mb-2">事件解決トラッキング番号</h3>
              <div className="text-3xl font-mono font-black text-rose-600 tracking-wider mb-2">{formData.caseNumber}</div>
              <p className="text-[10px] text-rose-500/80 font-bold">この番号を保存してください。事態が解決した際、または進展があった際に、後日「事件解決レポート」として追記評価を行うために必要です。</p>
            </div>
          )}

          <h2 className="text-3xl font-black text-slate-900 mb-4 tracking-tighter uppercase">監査記録を送信しました</h2>
          <p className="text-slate-500 font-medium mb-10 leading-relaxed">
            あなたの証言はシステムに記録され、該当警察署の評価統計に反映されます。<br />
            市民の監視が、より良い警察組織を作ります。
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            {formData.problemResolved === false && (
              <Link href={`/case/${formData.caseNumber}`} className="inline-flex items-center justify-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white px-6 py-4 rounded-2xl font-black transition-all text-sm">
                事件解決レポートを作成 (デモ)
              </Link>
            )}
            <Link href="/stats" className="inline-flex items-center justify-center space-x-2 bg-slate-100 hover:bg-slate-200 border border-slate-200 text-slate-900 px-6 py-4 rounded-2xl font-black transition-all text-sm">
              <BarChart3 className="w-4 h-4" />
              <span>全国統計を見る</span>
            </Link>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-24 pb-32">
      <div className="max-w-3xl mx-auto px-6">
        
        {/* Header */}
        <div className="text-center mb-12">
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-indigo-100 mb-6">
            <ShieldAlert className="w-8 h-8 text-indigo-600" />
          </div>
          <h1 className="text-4xl font-black text-slate-900 mb-4 tracking-tighter uppercase">Police Audit Report</h1>
          <p className="text-slate-500 font-bold text-sm max-w-xl mx-auto">
            警察の対応（あしらい、不受理、不適切な言動など）を記録・可視化するための監査フォームです。
          </p>
        </div>

        {/* Progress Tracker (4 Steps) */}
        <div className="flex items-center justify-center space-x-2 sm:space-x-4 mb-12 relative">
          <div className="absolute left-0 right-0 top-1/2 -translate-y-1/2 h-0.5 bg-slate-200 -z-10 mx-[10%]"></div>
          <div className="absolute left-0 top-1/2 -translate-y-1/2 h-0.5 bg-indigo-500 -z-10 transition-all duration-500 ml-[10%]" style={{ width: `${((step - 1) / 3) * 80}%` }}></div>
          
          {[1, 2, 3, 4].map((s) => {
            // 受理された場合、STEP 2 はスキップ扱いなのでグレーダウンするか「Skip」を表示する
            const isSkipped = s === 2 && formData.problemResolved === true;
            return (
              <div key={s} className={`flex flex-col items-center ${isSkipped ? 'opacity-30' : ''}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-black transition-all duration-500 ${step >= s && !isSkipped ? 'bg-indigo-600 text-white shadow-lg shadow-indigo-600/30' : 'bg-slate-100 text-slate-400 border border-slate-200'}`}>
                  {s}
                </div>
                <div className={`text-[8px] sm:text-[9px] mt-2 font-black uppercase tracking-widest ${step >= s && !isSkipped ? 'text-indigo-600' : 'text-slate-400'}`}>
                  {s === 1 ? '基本情報' : s === 2 ? '不受理詳細' : s === 3 ? '対応評価' : '確認と送信'}
                </div>
              </div>
            );
          })}
        </div>

        {/* Form Container */}
        <form onSubmit={handleSubmit} className="glass-card p-8 md:p-12 relative overflow-hidden">
          
          {/* Step 1: 管轄と受理状況 */}
          {step === 1 && (
            <div className="space-y-8 animate-in slide-in-from-right-8 duration-500">
              <div className="flex items-center space-x-3 mb-8 pb-6 border-b border-slate-200">
                <MapPin className="w-5 h-5 text-indigo-600" />
                <h2 className="text-xl font-black text-slate-900 uppercase tracking-widest">1. 管轄と受理状況</h2>
              </div>

              <div className="grid md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">① 発生地域</label>
                  <div className="relative">
                    <select 
                      required
                      value={formData.region}
                      onChange={e => setFormData({...formData, region: e.target.value, prefecture: ''})}
                      className="w-full bg-slate-50 border-slate-200 rounded-xl p-4 text-sm font-bold text-slate-900 appearance-none focus:ring-indigo-500 focus:bg-white transition-all outline-none border"
                    >
                      <option value="">地域を選択</option>
                      {Object.keys(REGION_MAP).map(region => (
                        <option key={region} value={region}>{region}</option>
                      ))}
                    </select>
                    <ChevronRight className="w-4 h-4 text-slate-400 absolute right-4 top-1/2 -translate-y-1/2 rotate-90 pointer-events-none" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">② 都道府県</label>
                  <div className="relative">
                    <select 
                      required
                      disabled={!formData.region}
                      value={formData.prefecture}
                      onChange={e => setFormData({...formData, prefecture: e.target.value})}
                      className="w-full bg-slate-50 border-slate-200 rounded-xl p-4 text-sm font-bold text-slate-900 appearance-none focus:ring-indigo-500 focus:bg-white transition-all outline-none border disabled:opacity-50 disabled:bg-slate-100"
                    >
                      <option value="">都道府県を選択</option>
                      {formData.region && REGION_MAP[formData.region].map(pref => (
                        <option key={pref} value={pref}>{pref}</option>
                      ))}
                    </select>
                    <ChevronRight className="w-4 h-4 text-slate-400 absolute right-4 top-1/2 -translate-y-1/2 rotate-90 pointer-events-none" />
                  </div>
                </div>
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">③ 対象の警察署</label>
                <div className="flex items-center space-x-3 mb-1">
                  <input 
                    type="text" 
                    required
                    placeholder="例：渋谷"
                    value={formData.policeStation}
                    onChange={e => setFormData({...formData, policeStation: e.target.value})}
                    className="w-full bg-slate-50 border-slate-200 rounded-xl p-4 text-sm font-bold text-slate-900 focus:ring-indigo-500 focus:bg-white transition-all outline-none border"
                  />
                  <span className="text-base font-black text-slate-700 whitespace-nowrap shrink-0">警察署</span>
                </div>
                <p className="text-[10px] text-slate-400 font-bold ml-1 leading-relaxed">
                  ※交番や派出所で相談した場合も、管轄する大元の警察署の名前を入力してください（「警察署」の入力は不要です）。
                </p>
              </div>

              <div className="space-y-4 pt-6 border-t border-slate-200">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center">
                  <Clock className="w-4 h-4 mr-2 text-indigo-500" />
                  ④ 警察に相談した年月（任意）
                </label>
                <input 
                  type="month"
                  value={formData.incidentYearMonth}
                  onChange={e => setFormData({...formData, incidentYearMonth: e.target.value})}
                  className="w-full bg-slate-50 border-slate-200 rounded-xl p-4 text-sm font-bold text-slate-900 focus:ring-indigo-500 focus:bg-white transition-all outline-none border"
                />
              </div>

              <div className="space-y-4 pt-6 border-t border-slate-200">
                <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest flex items-center">
                  <AlertOctagon className="w-4 h-4 mr-2 text-rose-500" />
                  ⑤ 事件は正式に受理されましたか？
                </label>
                <div className="grid grid-cols-2 gap-4">
                  <button
                    type="button"
                    onClick={() => setFormData({...formData, problemResolved: true})}
                    className={`flex flex-col items-center justify-center p-6 rounded-2xl border-2 transition-all ${formData.problemResolved === true ? 'bg-emerald-50 border-emerald-500 text-emerald-600 shadow-lg' : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100'}`}
                  >
                    <ThumbsUp className="w-8 h-8 mb-3" />
                    <span className="font-black text-sm">はい、受理された</span>
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({...formData, problemResolved: false})}
                    className={`flex flex-col items-center justify-center p-6 rounded-2xl border-2 transition-all ${formData.problemResolved === false ? 'bg-rose-50 border-rose-500 text-rose-600 shadow-lg' : 'bg-slate-50 border-slate-200 text-slate-500 hover:bg-slate-100'}`}
                  >
                    <ThumbsDown className="w-8 h-8 mb-3" />
                    <span className="font-black text-sm">いいえ、不受理・放置された</span>
                  </button>
                </div>
                {formData.problemResolved === true && (
                  <p className="text-[10px] text-emerald-600 font-bold px-2 animate-in fade-in">※「はい」を選んだ場合、次の不受理理由の入力をスキップして警察対応の評価へ進みます。</p>
                )}
              </div>

              <div className="pt-6 mt-8 border-t border-slate-200">
                <div className="p-4 bg-rose-50 border border-rose-200 rounded-xl">
                  <div className="text-[11px] font-black text-rose-600 uppercase tracking-widest mb-1 flex items-center">
                    <CheckCircle className="w-4 h-4 mr-1" />
                    法的誓約および同意
                  </div>
                  <div className="text-[10px] text-slate-600 font-bold leading-relaxed">
                    私は、この報告内容が事実に基づくものであり、特定の個人や機関を不当に貶める虚偽の申告ではないことを誓約します。<br/>
                    不正な評価操作（改竄）を行った場合、統計から除外されることに同意します。
                  </div>
                </div>
              </div>

              <div className="mt-10 flex justify-end">
                <button 
                  type="button" 
                  onClick={nextStep}
                  disabled={!formData.region || !formData.prefecture || !formData.policeStation || formData.problemResolved === null}
                  className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-2xl font-black transition-all shadow-xl uppercase tracking-widest text-sm disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  <span>次へ進む</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Step 2: 不受理の詳細入力 (スキップ可能) */}
          {step === 2 && (
            <div className="space-y-8 animate-in slide-in-from-right-8 duration-500">
              <div className="flex items-center space-x-3 mb-4 pb-4 border-b border-slate-200">
                <FileText className="w-5 h-5 text-indigo-600" />
                <h2 className="text-xl font-black text-slate-900 uppercase tracking-widest">2. 不受理の詳細</h2>
              </div>

              {/* ① 証拠の有無と量 */}
              <div className="space-y-4 mb-8">
                <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">① 証拠の有無と量（動画・録音・診断書・メッセージ履歴など）</h3>
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  <button
                    type="button"
                    onClick={() => setFormData({...formData, evidenceLevel: '多数の証拠'})}
                    className={`p-4 rounded-xl text-xs sm:text-sm font-black transition-all border-2 ${formData.evidenceLevel === '多数の証拠' ? 'bg-indigo-600 border-indigo-600 text-white shadow-md' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'}`}
                  >
                    多数の証拠を持参した
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({...formData, evidenceLevel: '少数の証拠'})}
                    className={`p-4 rounded-xl text-xs sm:text-sm font-black transition-all border-2 ${formData.evidenceLevel === '少数の証拠' ? 'bg-indigo-500 border-indigo-500 text-white shadow-md' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'}`}
                  >
                    少数の証拠を持参した
                  </button>
                  <button
                    type="button"
                    onClick={() => setFormData({...formData, evidenceLevel: '証拠なし'})}
                    className={`p-4 rounded-xl text-xs sm:text-sm font-black transition-all border-2 ${formData.evidenceLevel === '証拠なし' ? 'bg-slate-600 border-slate-600 text-white shadow-md' : 'bg-white border-slate-200 text-slate-500 hover:bg-slate-50'}`}
                  >
                    証拠は持参できなかった
                  </button>
                </div>
              </div>

              {/* ② 事件カテゴリ */}
              <div className="space-y-4 mb-8 pt-6 border-t border-slate-200">
                <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">② 事件カテゴリ（どのようなトラブルを持ち込みましたか？ 複数選択可）</h3>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                  {INCIDENT_CATEGORIES.map(type => (
                    <button
                      key={type}
                      type="button"
                      onClick={() => handleIncidentTypeToggle(type)}
                      className={`p-3 rounded-xl text-xs font-bold transition-all border ${formData.incidentTypes.includes(type) ? 'bg-indigo-600 text-white border-indigo-500 shadow-md' : 'bg-slate-50 text-slate-600 border-slate-200 hover:bg-slate-100'}`}
                    >
                      {type}
                    </button>
                  ))}
                </div>
                
                {formData.incidentTypes.includes('その他') && (
                  <div className="mt-4 animate-in fade-in slide-in-from-top-2">
                    <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-2">その他（具体的な事件カテゴリを入力してください）</label>
                    <input 
                      type="text" 
                      placeholder="例：自転車泥棒、空き巣など"
                      value={formData.otherIncidentType}
                      onChange={e => setFormData({...formData, otherIncidentType: e.target.value})}
                      className="w-full bg-slate-50 border-slate-200 rounded-xl p-4 text-sm font-bold text-slate-900 focus:ring-indigo-500 focus:bg-white transition-all outline-none border"
                    />
                  </div>
                )}
              </div>

              {/* ③ 不受理の理由 */}
              <div className="space-y-4 pt-6 border-t border-slate-200">
                <div className="bg-rose-50 border border-rose-200 p-5 rounded-2xl animate-in fade-in duration-300">
                  <p className="text-[10px] font-black text-rose-600 uppercase tracking-widest mb-3">③ 警察が提示した不受理の理由（複数選択可）</p>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {['民事不介入', '証拠が足りない', '事件性が低い', '管轄外', '被害が軽微すぎる', '加害者の特定が困難', '明確な説明なし'].map(reason => (
                      <label key={reason} className="flex items-center space-x-2 cursor-pointer p-2 hover:bg-white/50 rounded-lg transition-colors">
                        <input 
                          type="checkbox" 
                          checked={formData.denialReasons.includes(reason)}
                          onChange={() => handleDenialReasonToggle(reason)}
                          className="appearance-none w-4 h-4 border-2 border-rose-300 rounded bg-white checked:bg-rose-600 checked:border-rose-600 transition-all cursor-pointer"
                        />
                        <span className="text-xs font-bold text-slate-700">{reason}</span>
                      </label>
                    ))}
                  </div>
                </div>
              </div>

              <div className="mt-10 flex justify-between">
                <button type="button" onClick={prevStep} className="text-slate-500 font-black text-[10px] uppercase tracking-widest hover:text-slate-900 transition-all">戻る</button>
                <button 
                  type="button" 
                  onClick={nextStep}
                  disabled={!formData.evidenceLevel || formData.incidentTypes.length === 0 || (formData.incidentTypes.includes('その他') && !formData.otherIncidentType.trim())}
                  className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-2xl font-black transition-all shadow-xl uppercase tracking-widest text-sm disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  <span>次へ進む</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Step 3: 警察対応評価 (全員が回答) */}
          {step === 3 && (
            <div className="space-y-8 animate-in slide-in-from-right-8 duration-500">
              <div className="flex items-center space-x-3 mb-4 pb-4 border-b border-slate-200">
                <Scale className="w-5 h-5 text-indigo-600" />
                <h2 className="text-xl font-black text-slate-900 uppercase tracking-widest">3. 警察対応評価</h2>
              </div>

              <div className="space-y-4">
                <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">警察官の基本評価（5段階）</h3>
                {[
                  { key: 'evalListening', label: '傾聴姿勢', desc: '話を遮らず、真摯に状況を聞き取ろうとしたか' },
                  { key: 'evalLegalExplanation', label: '法的根拠の説明', desc: '対応の可否について、法的根拠に基づく説明はあったか' },
                  { key: 'evalAttitude', label: '態度の適切さ', desc: '高圧的、威圧的、または見下すような態度はなかったか' },
                  { key: 'evalInvestigation', label: '捜査の意思', desc: '証拠の確認など、事実を調査しようとする姿勢はあったか' },
                  { key: 'evalFairness', label: '公平性', desc: '加害者側に偏らず、公平な立場からの対応だったか' }
                ].map((metric) => (
                  <div key={metric.key} className="bg-slate-50 border border-slate-200 p-5 rounded-2xl">
                    <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                      <div>
                        <h4 className="text-sm font-black text-slate-900">{metric.label}</h4>
                        <p className="text-[10px] font-bold text-slate-500 mt-1">{metric.desc}</p>
                      </div>
                      <div className="flex space-x-2">
                        {[1, 2, 3, 4, 5].map((val) => (
                          <button
                            key={val}
                            type="button"
                            onClick={() => handleRating(metric.key, val)}
                            className={`w-8 h-8 md:w-10 md:h-10 rounded-xl flex items-center justify-center font-black transition-all ${formData[metric.key] === val ? (val <= 2 ? 'bg-rose-500 text-white shadow-lg shadow-rose-500/30' : val >= 4 ? 'bg-emerald-500 text-white shadow-lg shadow-emerald-500/30' : 'bg-indigo-500 text-white shadow-lg shadow-indigo-500/30') : 'bg-white border border-slate-200 text-slate-400 hover:bg-slate-100'}`}
                          >
                            {val}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>
                ))}
              </div>

              <div className="space-y-4 pt-6 border-t border-slate-200">
                <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4">対応チェックリスト</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {[
                    { key: 'hasCaseNumber', label: '事件番号は発行されたか' },
                    { key: 'hasGuidelineExplanation', label: '今後の手続きの説明はあったか' },
                    { key: 'isCivilInterventionRefused', label: '「民事不介入」を理由に拒絶されたか' },
                    { key: 'hasSupportProposal', label: '解決や身の安全に向けた具体的なサポート（パトロール等）の提案はあったか' },
                    { key: 'isExcellentResponse', label: '親身な配慮や、迅速・的確なサポートがあった（優良対応）' }
                  ].map(flag => (
                    <div key={flag.key} className={`flex items-center justify-between p-4 rounded-xl border ${flag.key === 'isExcellentResponse' ? 'bg-emerald-50 border-emerald-200' : 'bg-white border-slate-200'}`}>
                      <span className={`text-xs font-bold ${flag.key === 'isExcellentResponse' ? 'text-emerald-700' : 'text-slate-700'}`}>{flag.label}</span>
                      <div className="flex space-x-2">
                        <button type="button" onClick={() => setFormData({...formData, [flag.key]: true})} className={`px-3 py-1 text-xs font-black rounded-lg transition-all shrink-0 ${formData[flag.key] === true ? (flag.key === 'isExcellentResponse' ? 'bg-emerald-600 text-white' : 'bg-indigo-600 text-white') : 'bg-slate-100 text-slate-400 hover:bg-slate-200'}`}>はい</button>
                        <button type="button" onClick={() => setFormData({...formData, [flag.key]: false})} className={`px-3 py-1 text-xs font-black rounded-lg transition-all shrink-0 ${formData[flag.key] === false ? (flag.key === 'isExcellentResponse' ? 'bg-rose-500 text-white' : 'bg-indigo-600 text-white') : 'bg-slate-100 text-slate-400 hover:bg-slate-200'}`}>いいえ</button>
                      </div>
                    </div>
                  ))}
                </div>
                
                {formData.isExcellentResponse === true && (
                  <div className="mt-4 p-5 bg-emerald-50 border border-emerald-200 rounded-2xl animate-in fade-in slide-in-from-top-2">
                    <label className="text-[10px] font-black text-emerald-700 uppercase tracking-widest block mb-2">感謝のメッセージ（任意）</label>
                    <p className="text-[10px] text-emerald-600 font-bold mb-3">このメッセージは「警察署の優良対応の実績」として全国統計データに公開され、真面目な担当者の励みになります。※個人を特定できる名前などは書かないでください。</p>
                    <textarea 
                      rows="3"
                      placeholder="例：親身になって話を聞いてくれて、とても心が救われました。迅速な対応に感謝します。"
                      value={formData.gratitudeComment}
                      onChange={e => setFormData({...formData, gratitudeComment: e.target.value})}
                      className="w-full bg-white border-emerald-200 rounded-xl p-4 text-sm font-bold text-slate-900 focus:ring-emerald-500 focus:bg-white transition-all outline-none border resize-none"
                    />
                  </div>
                )}
              </div>

              <div className="mt-10 flex justify-between">
                <button type="button" onClick={prevStep} className="text-slate-500 font-black text-[10px] uppercase tracking-widest hover:text-slate-900 transition-all">戻る</button>
                <button 
                  type="button" 
                  onClick={nextStep}
                  disabled={formData.evalListening === 0 || formData.evalLegalExplanation === 0 || formData.evalAttitude === 0 || formData.evalInvestigation === 0 || formData.evalFairness === 0}
                  className="flex items-center space-x-2 bg-indigo-600 hover:bg-indigo-700 text-white px-8 py-4 rounded-2xl font-black transition-all shadow-xl uppercase tracking-widest text-sm disabled:opacity-30 disabled:cursor-not-allowed"
                >
                  <span>次へ進む</span>
                  <ArrowRight className="w-4 h-4" />
                </button>
              </div>
            </div>
          )}

          {/* Step 4: 確認と送信 */}
          {step === 4 && (
            <div className="space-y-8 animate-in slide-in-from-right-8 duration-500">
              <div className="flex items-center space-x-3 mb-8 pb-6 border-b border-slate-200">
                <ClipboardCheck className="w-5 h-5 text-indigo-600" />
                <h2 className="text-xl font-black text-slate-900 uppercase tracking-widest">4. 確認と送信</h2>
              </div>

              <div className="pt-2 space-y-8">
                <div className="p-6 bg-slate-50 border border-slate-200 rounded-xl text-center">
                  <p className="text-sm font-bold text-slate-700 mb-2">入力内容をご確認の上、「監査記録を送信」ボタンを押してください。</p>
                  <p className="text-[10px] text-slate-500 font-bold">※送信後、内容は修正できません。この記録は全国の警察対応統計として集計されます。</p>
                </div>

                <div className="flex justify-between items-center">
                  <button type="button" onClick={prevStep} className="text-slate-500 font-black text-[10px] uppercase tracking-widest hover:text-slate-900 transition-all">戻る</button>
                  <button 
                    type="submit"
                    className="bg-indigo-600 hover:bg-indigo-700 text-white px-10 py-5 rounded-2xl font-black transition-all shadow-xl uppercase tracking-widest text-sm"
                  >
                    監査記録を送信
                  </button>
                </div>
              </div>
            </div>
          )}
        </form>

      </div>
    </div>
  );
}
