import Link from 'next/link';
import { ShieldAlert } from 'lucide-react';

export default function Footer() {
  return (
    <footer className="bg-slate-900 text-slate-400 py-12 mt-20">
      <div className="max-w-6xl mx-auto px-6">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-8 pb-8 border-b border-slate-800">
          
          <div className="col-span-1 md:col-span-2">
            <Link href="/" className="inline-flex items-center space-x-2 mb-4 group">
              <div className="w-8 h-8 bg-indigo-500 rounded-lg flex items-center justify-center group-hover:scale-105 transition-transform">
                <ShieldAlert className="w-5 h-5 text-white" />
              </div>
              <div className="flex flex-col leading-none">
                <span className="text-lg font-black tracking-tighter text-white">警察署評価マップ</span>
                <span className="text-[7px] font-black tracking-[0.3em] text-indigo-400 uppercase mt-0.5">-『助けての声』を可視化する-</span>
              </div>
            </Link>
            <p className="text-xs font-bold leading-relaxed max-w-sm">
              本プラットフォームは市民の証言に基づき、公的機関の対応を透明化・監査するための民間のプロジェクトです。警察等の公的機関とは一切関係ありません。
            </p>
          </div>

          <div>
            <h4 className="text-white font-black text-sm mb-4 tracking-widest uppercase">メニュー</h4>
            <ul className="space-y-2 text-xs font-bold">
              <li><Link href="/" className="hover:text-indigo-400 transition-colors">ホーム</Link></li>
              <li><Link href="/stats" className="hover:text-indigo-400 transition-colors">全国統計データ</Link></li>
              <li><Link href="/report" className="hover:text-indigo-400 transition-colors">監査レポートを作成</Link></li>
            </ul>
          </div>

          <div>
            <h4 className="text-white font-black text-sm mb-4 tracking-widest uppercase">法的情報</h4>
            <ul className="space-y-2 text-xs font-bold">
              <li><span className="hover:text-indigo-400 transition-colors cursor-pointer">利用規約</span></li>
              <li><span className="hover:text-indigo-400 transition-colors cursor-pointer">プライバシーポリシー</span></li>
              <li><span className="hover:text-indigo-400 transition-colors cursor-pointer">免責事項</span></li>
            </ul>
          </div>

        </div>

        <div className="flex flex-col md:flex-row items-center justify-between text-[10px] font-bold">
          <p>&copy; {new Date().getFullYear()} 警察署評価マップ (Police Conduct Monitor). All rights reserved.</p>
          <p className="mt-2 md:mt-0">Powered by Citizens.</p>
        </div>
      </div>
    </footer>
  );
}
