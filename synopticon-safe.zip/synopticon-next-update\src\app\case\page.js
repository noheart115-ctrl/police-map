"use client";

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import {
  AlertOctagon,
  Search,
  ArrowRight,
  Clock,
  FileText,
  ShieldAlert
} from 'lucide-react';

/**
 * 事件解決フォームのエントリーページ
 * 案件番号を入力して、対応する解決フォームに進む
 */
export default function CasePage() {
  const [caseInput, setCaseInput] = useState('');
  const [error, setError] = useState('');
  const router = useRouter();

  const handleSubmit = (e) => {
    e.preventDefault();
    const trimmed = caseInput.trim().toUpperCase();
    // KPM-YYYY-XXXXXX 形式のバリデーション
    if (!trimmed.match(/^KPM-\d{4}-[A-Z0-9]{6}$/)) {
      setError('案件番号の形式が正しくありません（例: KPM-2026-A3F8KZ）');
      return;
    }
    router.push(`/case/${trimmed}`);
  };

  return (
    <div className="min-h-screen pt-24 pb-32">
      <div className="max-w-2xl mx-auto px-6">

        {/* ヘッダー */}
        <div className="mb-12 text-center">
          <div className="inline-flex items-center justify-center w-16 h-16 bg-indigo-100 rounded-2xl mb-6 border border-indigo-200">
            <AlertOctagon className="w-8 h-8 text-indigo-600" />
          </div>
          <h1 className="text-3xl font-black text-slate-900 tracking-tighter uppercase mb-3">
            事件解決フォーム
          </h1>
          <p className="text-slate-500 font-bold text-sm leading-relaxed">
            監査レポート送信時に発行された<span className="text-indigo-600">案件番号</span>を入力して<br />
            事件の続報・解決状況を記録してください
          </p>
        </div>

        {/* 番号入力フォーム */}
        <div className="glass-card p-10 space-y-8 bg-white border border-slate-200">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="space-y-3">
              <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest">
                案件番号を入力
              </label>
              <div className="relative">
                <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input
                  type="text"
                  placeholder="KPM-2026-XXXXXX"
                  value={caseInput}
                  onChange={e => { setCaseInput(e.target.value); setError(''); }}
                  className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-12 pr-4 py-5 text-base font-black text-slate-900 font-mono focus:ring-indigo-500 focus:border-indigo-500 focus:bg-white transition-all outline-none tracking-widest uppercase shadow-sm"
                />
              </div>
              {error && (
                <p className="text-[11px] text-rose-500 font-bold flex items-center space-x-1">
                  <AlertOctagon className="w-3 h-3" />
                  <span>{error}</span>
                </p>
              )}
              <p className="text-[9px] text-slate-400 font-bold">
                ※ 案件番号は「KPM-（年）-（英数字6文字）」の形式です
              </p>
            </div>

            <button
              type="submit"
              disabled={!caseInput.trim()}
              className="w-full flex items-center justify-center space-x-3 bg-indigo-600 hover:bg-indigo-700 text-white py-5 rounded-2xl font-black transition-all shadow-xl shadow-indigo-600/20 uppercase tracking-widest text-sm disabled:opacity-30"
            >
              <span>事件解決フォームへ進む</span>
              <ArrowRight className="w-4 h-4" />
            </button>
          </form>
        </div>

        {/* 説明セクション */}
        <div className="mt-10 grid grid-cols-1 md:grid-cols-3 gap-4">
          {[
            { icon: FileText,    title: '案件番号とは',   desc: '監査レポートで「問題が解決していない」を選択した際に自動発行される追跡番号です。' },
            { icon: Clock,       title: 'いつでも記録可能', desc: '事件の進展があった際、このページに番号を入力して続報を追記できます。' },
            { icon: ShieldAlert, title: '統計に反映',     desc: '記録された解決状況は都道府県・警察署ごとの統計データに匿名で反映されます。' },
          ].map(item => (
            <div key={item.title} className="glass-card p-6 space-y-3 bg-slate-50 border border-slate-200 hover:border-indigo-200 transition-colors">
              <div className="p-2 bg-indigo-100 rounded-xl w-fit border border-indigo-200">
                <item.icon className="w-4 h-4 text-indigo-600" />
              </div>
              <div className="text-[11px] font-black text-slate-900 uppercase tracking-widest">{item.title}</div>
              <p className="text-[10px] text-slate-500 font-bold leading-relaxed">{item.desc}</p>
            </div>
          ))}
        </div>

      </div>
    </div>
  );
}
