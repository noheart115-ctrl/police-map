"use client";

import Link from 'next/link';
import { 
  BellRing, 
  AlertTriangle, 
  ThumbsUp, 
  ShieldCheck, 
  ChevronLeft,
  ArrowRight,
  Clock
} from 'lucide-react';

export default function NewsPage() {
  const newsItems = [];

  const getColorClasses = (color) => {
    switch(color) {
      case 'rose': return 'bg-rose-50 text-rose-600 border-rose-200';
      case 'emerald': return 'bg-emerald-50 text-emerald-600 border-emerald-200';
      case 'amber': return 'bg-amber-50 text-amber-600 border-amber-200';
      case 'indigo': return 'bg-indigo-50 text-indigo-600 border-indigo-200';
      default: return 'bg-slate-50 text-slate-600 border-slate-200';
    }
  };

  const getBadgeText = (type) => {
    switch(type) {
      case 'warning': return '警告';
      case 'alert': return '注意喚起';
      default: return 'お知らせ';
    }
  };

  return (
    <div className="min-h-screen pt-24 pb-32 bg-slate-50">
      <div className="max-w-4xl mx-auto px-6">
        
        {/* ヘッダー */}
        <div className="flex flex-col md:flex-row md:items-center justify-between mb-12 gap-6">
          <div>
            <div className="inline-flex items-center space-x-2 bg-rose-100 text-rose-600 px-3 py-1 rounded-full text-[10px] font-black uppercase tracking-widest mb-3">
              <AlertTriangle className="w-3 h-3" />
              <span>National Crime Alerts</span>
            </div>
            <h1 className="text-3xl sm:text-4xl font-black text-slate-900 tracking-tighter">
              ニュースでの件数が増えている要注意事象
            </h1>
            <p className="text-slate-500 font-bold mt-2 text-sm leading-relaxed">
              全国のニュースや警察の公式発表を集約し、今気をつけるべき防犯の基本をお届けします。<br className="hidden sm:block" />
              一人ひとりの防犯意識が、地域全体の抑止力に繋がります。
            </p>
          </div>
          
          <Link 
            href="/"
            className="inline-flex items-center space-x-2 text-slate-500 hover:text-slate-900 font-bold text-sm transition-colors"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>トップへ戻る</span>
          </Link>
        </div>

        {/* ニュースリスト */}
        <div className="space-y-6">
          {newsItems.map((item) => {
            const Icon = item.icon;
            const colorClasses = getColorClasses(item.color);
            return (
              <div key={item.id} className="bg-white rounded-2xl p-6 sm:p-8 shadow-sm border border-slate-100 hover:shadow-md transition-shadow group">
                <div className="flex flex-col sm:flex-row gap-6">
                  {/* アイコン部分 */}
                  <div className={`w-14 h-14 rounded-2xl flex items-center justify-center shrink-0 border ${colorClasses}`}>
                    <Icon className="w-7 h-7" />
                  </div>
                  
                  {/* コンテンツ部分 */}
                  <div className="flex-1">
                    <div className="flex flex-wrap items-center gap-3 mb-3">
                      <span className={`text-[10px] font-black px-3 py-1 rounded-full uppercase tracking-widest border ${colorClasses}`}>
                        {getBadgeText(item.type)}
                      </span>
                      <div className="flex items-center text-slate-400 text-xs font-bold">
                        <Clock className="w-3 h-3 mr-1" />
                        {item.date}
                      </div>
                      <div className="flex items-center text-indigo-500 text-xs font-bold bg-indigo-50 px-2 py-0.5 rounded-md border border-indigo-100">
                        <span>全国 {item.sourcesCount} 件の類似ニュースより集計</span>
                      </div>
                    </div>
                    
                    <h2 className="text-xl font-black text-slate-900 mb-3 leading-tight group-hover:text-indigo-600 transition-colors">
                      {item.title}
                    </h2>
                    
                    <p className="text-sm text-slate-600 font-bold leading-relaxed">
                      {item.content}
                    </p>
                  </div>
                </div>
              </div>
            );
          })}
        </div>

        {/* フッターアクション */}
        <div className="mt-16 bg-gradient-to-br from-indigo-900 to-slate-900 rounded-3xl p-8 sm:p-12 text-center relative overflow-hidden">
          <div className="absolute top-0 right-0 w-64 h-64 bg-indigo-500/20 blur-[80px] rounded-full pointer-events-none" />
          <h3 className="text-2xl font-black text-white mb-4 relative z-10">あなたの声が、次の抑止力になる</h3>
          <p className="text-indigo-200 font-bold text-sm mb-8 max-w-lg mx-auto relative z-10 leading-relaxed">
            理不尽な対応を受けた経験も、親身になってくれた感謝の記憶も、すべてが警察組織を良くするためのデータになります。
          </p>
          <Link 
            href="/report"
            className="inline-flex items-center justify-center space-x-3 bg-white hover:bg-slate-50 text-indigo-600 px-8 py-4 rounded-xl font-black transition-all uppercase tracking-widest text-sm shadow-xl relative z-10 hover:-translate-y-1"
          >
            <ShieldCheck className="w-5 h-5" />
            <span>監査レポートを作成する</span>
            <ArrowRight className="w-4 h-4" />
          </Link>
        </div>

      </div>
    </div>
  );
}
